import {
  HTMLRewriter,
  __require
} from "./chunk-ECGXHPZS.js";

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/matchers.json
var matchers_default = [{ regexp: "^(?:\\/(_next\\/data\\/[^/]{1,}))?(?:\\/((?!api|_next|nemovitost\\/|.*\\..*).*))(\\.json|\\.rsc|\\.segments\\/.+\\.segment\\.rsc)?[\\/#\\?]?$", originalSource: "/((?!api|_next|nemovitost/|.*\\..*).*)" }];

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/next.config.json
var next_config_default = { basePath: "", i18n: null, trailingSlash: false };

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/headers.ts
var InternalHeaders = {
  NFDebugLogging: "x-nf-debug-logging",
  NFRequestID: "x-nf-request-id"
};
function updateModifiedHeaders(requestHeaders, responseHeaders) {
  const overriddenHeaders = responseHeaders.get("x-middleware-override-headers");
  if (!overriddenHeaders) {
    return;
  }
  const headersToUpdate = new Set(overriddenHeaders.split(",").map((header) => header.trim()));
  for (const key of [
    ...requestHeaders.keys()
  ]) {
    if (!headersToUpdate.has(key)) {
      requestHeaders.delete(key);
    }
  }
  for (const header of headersToUpdate) {
    const oldHeaderKey = "x-middleware-request-" + header;
    const headerValue = responseHeaders.get(oldHeaderKey) || "";
    const oldValue = requestHeaders.get(header) || "";
    if (oldValue !== headerValue) {
      if (headerValue) {
        requestHeaders.set(header, headerValue);
      } else {
        requestHeaders.delete(header);
      }
    }
    responseHeaders.delete(oldHeaderKey);
  }
  responseHeaders.delete("x-middleware-override-headers");
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/v1-7-0--edge-utils.netlify.app/logger/logger.ts
var LogLevel = /* @__PURE__ */ function(LogLevel2) {
  LogLevel2[LogLevel2["Debug"] = 1] = "Debug";
  LogLevel2[LogLevel2["Log"] = 2] = "Log";
  LogLevel2[LogLevel2["Error"] = 3] = "Error";
  return LogLevel2;
}({});
var serializeError = (error) => {
  const cause = error?.cause instanceof Error ? serializeError(error.cause) : error.cause;
  return {
    error: error.message,
    error_cause: cause,
    error_stack: error.stack
  };
};
var StructuredLogger = class _StructuredLogger {
  fields;
  logLevel;
  message;
  rawLogger;
  requestID;
  __netlifyStructuredLogger;
  constructor(message, fields, requestID, rawLogger, logLevel) {
    this.fields = fields ?? {};
    this.logLevel = logLevel ?? LogLevel.Log;
    this.message = message ?? "";
    this.rawLogger = rawLogger;
    this.requestID = requestID;
    this.__netlifyStructuredLogger = 1;
  }
  debug(message) {
    if (this.logLevel > LogLevel.Debug) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  error(message) {
    if (this.logLevel > LogLevel.Error) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  log(message) {
    if (this.logLevel > LogLevel.Log) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  serialize() {
    const log = {
      fields: this.fields,
      message: this.message,
      requestID: this.requestID
    };
    return log;
  }
  withError(error) {
    const fields = error instanceof Error ? serializeError(error) : {
      error
    };
    return this.withFields(fields);
  }
  withFields(fields) {
    return new _StructuredLogger(this.message, {
      ...this.fields,
      ...fields
    }, this.requestID, this.rawLogger, this.logLevel);
  }
  withLogLevel(logLevel) {
    return new _StructuredLogger(this.message, this.fields, this.requestID, this.rawLogger, logLevel);
  }
  withRawLogger(logger2) {
    return new _StructuredLogger(this.message, this.fields, this.requestID, logger2, this.logLevel);
  }
  withRequestID(requestID) {
    if (requestID === null) {
      return this;
    }
    return new _StructuredLogger(this.message, this.fields, requestID, this.rawLogger, this.logLevel);
  }
};
var logger = new StructuredLogger();

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/util.ts
function normalizeDataUrl(urlPath) {
  if (urlPath.startsWith("/_next/data/") && urlPath.includes(".json")) {
    const paths = urlPath.replace(/^\/_next\/data\//, "").replace(/\.json/, "").split("/");
    urlPath = paths[1] !== "index" ? `/${paths.slice(1).join("/")}` : "/";
  }
  return urlPath;
}
var removeBasePath = (path, basePath) => {
  if (basePath && path.startsWith(basePath)) {
    return path.replace(basePath, "");
  }
  return path;
};
var addBasePath = (path, basePath) => {
  if (basePath && !path.startsWith(basePath)) {
    return `${basePath}${path}`;
  }
  return path;
};
var addLocale = (path, locale) => {
  if (locale && path.toLowerCase() !== `/${locale.toLowerCase()}` && !path.toLowerCase().startsWith(`/${locale.toLowerCase()}/`) && !path.startsWith(`/api/`) && !path.startsWith(`/_next/`)) {
    return `/${locale}${path}`;
  }
  return path;
};
function normalizeLocalePath(pathname, locales) {
  let detectedLocale;
  const pathnameParts = pathname.split("/");
  (locales || []).some((locale) => {
    if (pathnameParts[1] && pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join("/");
      return true;
    }
    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}
function relativizeURL(url, base) {
  const baseURL = typeof base === "string" ? new URL(base) : base;
  const relative = new URL(url, base);
  const origin = `${baseURL.protocol}//${baseURL.host}`;
  return `${relative.protocol}//${relative.host}` === origin ? relative.toString().replace(origin, "") : relative.toString();
}
var normalizeIndex = (path) => path === "/" ? "/index" : path;
var normalizeTrailingSlash = (path, trailingSlash) => trailingSlash ? addTrailingSlash(path) : stripTrailingSlash(path);
var stripTrailingSlash = (path) => path !== "/" && path.endsWith("/") ? path.slice(0, -1) : path;
var addTrailingSlash = (path) => path.endsWith("/") ? path : `${path}/`;
function rewriteDataPath({ dataUrl, newRoute, basePath }) {
  const normalizedDataUrl = normalizeDataUrl(removeBasePath(dataUrl, basePath));
  return addBasePath(dataUrl.replace(normalizeIndex(normalizedDataUrl), stripTrailingSlash(normalizeIndex(newRoute))), basePath);
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/next-request.ts
var normalizeRequestURL = (originalURL, nextConfig) => {
  const url = new URL(originalURL);
  let pathname = removeBasePath(url.pathname, nextConfig?.basePath);
  const { detectedLocale } = normalizeLocalePath(pathname, nextConfig?.i18n?.locales);
  if (!nextConfig?.skipMiddlewareUrlNormalize) {
    pathname = normalizeDataUrl(pathname);
    if (nextConfig?.trailingSlash) {
      pathname = addTrailingSlash(pathname);
    }
  }
  url.pathname = addBasePath(pathname, nextConfig?.basePath);
  return {
    url: url.toString(),
    detectedLocale
  };
};
var localizeRequest = (url, nextConfig) => {
  const localizedUrl = new URL(url);
  const pathnameWithoutBasePath = removeBasePath(localizedUrl.pathname, nextConfig?.basePath);
  const isDataRequest = pathnameWithoutBasePath.startsWith("/_next/data/");
  const normalizedPath = isDataRequest ? normalizeDataUrl(pathnameWithoutBasePath) : pathnameWithoutBasePath;
  const { detectedLocale } = normalizeLocalePath(normalizedPath, nextConfig?.i18n?.locales);
  const normalizedPathWithLocale = addLocale(normalizedPath, detectedLocale ?? nextConfig?.i18n?.defaultLocale);
  localizedUrl.pathname = addBasePath(isDataRequest ? rewriteDataPath({
    dataUrl: pathnameWithoutBasePath,
    newRoute: normalizedPathWithLocale
  }) : normalizedPathWithLocale, nextConfig?.basePath);
  return {
    localizedUrl,
    locale: detectedLocale
  };
};
var buildNextRequest = (request, context, nextConfig) => {
  const { url, method, body, headers } = request;
  const { country, subdivision, city, latitude, longitude, timezone } = context.geo;
  const geo = {
    city,
    country: country?.code,
    region: subdivision?.code,
    latitude: latitude?.toString(),
    longitude: longitude?.toString(),
    timezone
  };
  const { detectedLocale, url: normalizedUrl } = normalizeRequestURL(url, nextConfig);
  return {
    headers: Object.fromEntries(headers.entries()),
    geo,
    url: normalizedUrl,
    method,
    ip: context.ip,
    body: body ?? void 0,
    nextConfig,
    detectedLocale
  };
};

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/deno.land/std@0.175.0/_util/asserts.ts
var DenoStdInternalError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "DenoStdInternalError";
  }
};
function assert(expr, msg = "") {
  if (!expr) {
    throw new DenoStdInternalError(msg);
  }
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/deno.land/std@0.175.0/http/cookie.ts
function getCookies(headers) {
  const cookie = headers.get("Cookie");
  if (cookie != null) {
    const out = {};
    const c = cookie.split(";");
    for (const kv of c) {
      const [cookieKey, ...cookieVal] = kv.split("=");
      assert(cookieKey != null);
      const key = cookieKey.trim();
      out[key] = cookieVal.join("=");
    }
    return out;
  }
  return {};
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/middleware.ts
function isMiddlewareRequest(response) {
  return "originalRequest" in response;
}
function isMiddlewareResponse(response) {
  return "dataTransforms" in response;
}
var hasMiddlewareResponseHeadersToApply = (middlewareResponse, { ignoreHeaders = [] } = {}) => {
  return [
    ...middlewareResponse.headers.keys()
  ].filter((header) => !ignoreHeaders.includes(header)).length > 0;
};
var addMiddlewareHeaders = async (originResponse, middlewareResponse) => {
  if (!hasMiddlewareResponseHeadersToApply(middlewareResponse)) {
    return originResponse;
  }
  const res = await originResponse;
  const response = new Response(res.body, res);
  middlewareResponse.headers.forEach((value, key) => {
    if (key === "set-cookie") {
      response.headers.append(key, value);
    } else {
      response.headers.set(key, value);
    }
  });
  return response;
};
function mergeMiddlewareCookies(middlewareResponse, lambdaRequest) {
  let mergedCookies = getCookies(lambdaRequest.headers);
  const middlewareCookies = middlewareResponse.headers.get("x-middleware-set-cookie");
  if (middlewareCookies) {
    middlewareResponse.headers.delete("x-middleware-set-cookie");
    const regex = new RegExp(/,(?!\s)/);
    middlewareCookies.split(regex).forEach((entry) => {
      const [cookie] = entry.split("; ");
      const [name, value] = cookie.split("=");
      mergedCookies[name] = value;
    });
  }
  return Object.entries(mergedCookies).map((kv) => kv.join("=")).join("; ");
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/response.ts
var buildResponse = async ({ context, logger: logger2, request, result, nextConfig }) => {
  logger2.withFields({
    is_nextresponse_next: result.response.headers.has("x-middleware-next")
  }).debug("Building Next.js response");
  updateModifiedHeaders(request.headers, result.response.headers);
  if (isMiddlewareRequest(result.response)) {
    result.response = await result.response.next();
  }
  if (isMiddlewareResponse(result.response)) {
    const { response } = result;
    if (request.method === "HEAD" || request.method === "OPTIONS") {
      return response.originResponse;
    }
    if (response.cookies._headers?.has("set-cookie")) {
      response.originResponse.headers.set("set-cookie", response.cookies._headers.get("set-cookie"));
    }
    if (response.originResponse.headers.get("content-type")?.includes("application/json")) {
      const props = await response.originResponse.json();
      const transformed = response.dataTransforms.reduce((prev, transform) => {
        return transform(prev);
      }, props);
      const body = JSON.stringify(transformed);
      const headers = new Headers(response.headers);
      headers.set("content-length", String(body.length));
      return Response.json(transformed, {
        ...response,
        headers
      });
    }
    if (response.dataTransforms.length > 0 || response.elementHandlers.length > 0) {
      if (Deno.env.get("NETLIFY_LOG_HTML_REWRITER") === "true") {
        logger2.withFields({
          dataTransforms_count: response.dataTransforms.length,
          elementHandlers_count: response.elementHandlers.length
        }).log("Using HTMLRewriter for response transformation");
      }
      const { initHtmlRewriter } = await import("./html-rewriter-wasm-EHPDOK7I.js");
      await initHtmlRewriter();
      let buffer = "";
      const rewriter = new HTMLRewriter();
      if (response.dataTransforms.length > 0) {
        rewriter.on('script[id="__NEXT_DATA__"]', {
          text(textChunk) {
            buffer += textChunk.text;
            if (textChunk.lastInTextNode) {
              try {
                const data = JSON.parse(buffer.trim());
                const props = response.dataTransforms.reduce((prev, transform) => transform(prev), data.props);
                textChunk.replace(JSON.stringify({
                  ...data,
                  props
                }), {
                  html: true
                });
              } catch (err) {
                console.log("Could not parse", err);
              }
            } else {
              textChunk.remove();
            }
          }
        });
      }
      if (response.elementHandlers.length > 0) {
        response.elementHandlers.forEach(([selector, handlers]) => rewriter.on(selector, handlers));
      }
      return rewriter.transform(response.originResponse);
    } else {
      return response.originResponse;
    }
  }
  let edgeResponse = new Response(result.response.body, result.response);
  request.headers.set("x-nf-next-middleware", "skip");
  let rewrite = edgeResponse.headers.get("x-middleware-rewrite");
  let redirect = edgeResponse.headers.get("location");
  let nextRedirect = edgeResponse.headers.get("x-nextjs-redirect");
  const isDataReq = request.headers.has("x-nextjs-data");
  if (isDataReq && !redirect && !rewrite && !nextRedirect) {
    const requestUrl = new URL(request.url);
    const normalizedDataUrl = normalizeDataUrl(requestUrl.pathname);
    if (normalizedDataUrl !== requestUrl.pathname) {
      rewrite = `${normalizedDataUrl}${requestUrl.search}`;
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewritten data URL");
    }
  }
  if (rewrite) {
    logger2.withFields({
      rewrite_url: rewrite
    }).debug("Found middleware rewrite");
    const rewriteUrl = new URL(rewrite, request.url);
    const baseUrl = new URL(request.url);
    if (rewriteUrl.toString() === baseUrl.toString() && !hasMiddlewareResponseHeadersToApply(edgeResponse, {
      ignoreHeaders: [
        "x-middleware-rewrite"
      ]
    })) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewrite URL is the same as original URL and no response headers need to be applied");
      return;
    }
    const relativeUrl = relativizeURL(rewrite, request.url);
    if (isDataReq) {
      edgeResponse.headers.set("x-nextjs-rewrite", relativeUrl);
    }
    if (rewriteUrl.origin !== baseUrl.origin) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewriting to external url");
      const proxyRequest = await cloneRequest(rewriteUrl, request);
      for (const key of request.headers.keys()) {
        if (key.startsWith("x-nf-")) {
          proxyRequest.headers.delete(key);
        }
      }
      return addMiddlewareHeaders(fetch(proxyRequest, {
        redirect: "manual"
      }), edgeResponse);
    }
    if (isDataReq) {
      rewriteUrl.pathname = rewriteDataPath({
        dataUrl: new URL(request.url).pathname,
        newRoute: removeBasePath(rewriteUrl.pathname, nextConfig?.basePath),
        basePath: nextConfig?.basePath
      });
    } else {
      rewriteUrl.pathname = normalizeTrailingSlash(rewriteUrl.pathname, nextConfig?.trailingSlash);
    }
    const target = normalizeLocalizedTarget({
      target: rewriteUrl.toString(),
      request,
      nextConfig
    });
    if (target === request.url && !hasMiddlewareResponseHeadersToApply(edgeResponse, {
      ignoreHeaders: [
        "x-middleware-rewrite"
      ]
    })) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Normalized rewrite URL is the same as original URL and no response headers need to be applied");
      return;
    }
    edgeResponse.headers.set("x-middleware-rewrite", relativeUrl);
    request.headers.set("x-middleware-rewrite", target);
    const newRequest = await cloneRequest(target, request);
    const newRequestCookies = mergeMiddlewareCookies(edgeResponse, newRequest);
    if (newRequestCookies) {
      newRequest.headers.set("Cookie", newRequestCookies);
    }
    return addMiddlewareHeaders(context.next(newRequest), edgeResponse);
  }
  if (redirect) {
    redirect = normalizeLocalizedTarget({
      target: redirect,
      request,
      nextConfig
    });
    if (redirect === request.url) {
      if (hasMiddlewareResponseHeadersToApply(edgeResponse, {
        ignoreHeaders: [
          "location"
        ]
      })) {
        const headersWithoutLocation = new Headers(edgeResponse.headers);
        headersWithoutLocation.delete("location");
        headersWithoutLocation.set("x-middleware-next", "1");
        edgeResponse = new Response(null, {
          status: 200,
          headers: headersWithoutLocation
        });
      } else {
        logger2.withFields({
          redirect_url: redirect
        }).debug("Redirect url is the same as original URL and no response headers need to be applied");
        return;
      }
    }
    edgeResponse.headers.set("location", relativizeURL(redirect, request.url));
  }
  if (redirect && isDataReq) {
    edgeResponse.headers.delete("location");
    edgeResponse.headers.set("x-nextjs-redirect", relativizeURL(redirect, request.url));
  }
  nextRedirect = edgeResponse.headers.get("x-nextjs-redirect");
  if (nextRedirect && isDataReq) {
    edgeResponse.headers.set("x-nextjs-redirect", normalizeDataUrl(nextRedirect));
  }
  if (edgeResponse.headers.get("x-middleware-next") === "1") {
    edgeResponse.headers.delete("x-middleware-next");
    const newRequest = await cloneRequest(request.url, request);
    const newRequestCookies = mergeMiddlewareCookies(edgeResponse, newRequest);
    if (newRequestCookies) {
      newRequest.headers.set("Cookie", newRequestCookies);
    }
    return addMiddlewareHeaders(context.next(newRequest), edgeResponse);
  }
  return edgeResponse;
};
function normalizeLocalizedTarget({ target, request, nextConfig }) {
  const targetUrl = new URL(target, request.url);
  const normalizedTarget = normalizeLocalePath(targetUrl.pathname, nextConfig?.i18n?.locales);
  if (normalizedTarget.detectedLocale && !normalizedTarget.pathname.startsWith(`/api/`) && !normalizedTarget.pathname.startsWith(`/_next/static/`)) {
    targetUrl.pathname = addBasePath(`/${normalizedTarget.detectedLocale}${normalizedTarget.pathname}`, nextConfig?.basePath) || `/`;
  } else {
    targetUrl.pathname = addBasePath(normalizedTarget.pathname, nextConfig?.basePath) || `/`;
  }
  return targetUrl.toString();
}
async function cloneRequest(url, request) {
  const body = request.body && !request.bodyUsed ? await request.arrayBuffer() : void 0;
  return new Request(url, {
    headers: request.headers,
    method: request.method,
    body
  });
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/routing.ts
function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === "undefined") {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [
        query[key],
        value
      ];
    }
  });
  return query;
}
function matchHas(req, query, has = [], missing = []) {
  const params = {};
  const cookies = getCookies(req.headers);
  const url = new URL(req.url);
  const hasMatch = (hasItem) => {
    let value;
    let key = hasItem.key;
    switch (hasItem.type) {
      case "header": {
        key = hasItem.key.toLowerCase();
        value = req.headers.get(key);
        break;
      }
      case "cookie": {
        value = cookies[hasItem.key];
        break;
      }
      case "query": {
        value = query[hasItem.key];
        break;
      }
      case "host": {
        value = url.hostname;
        break;
      }
      default: {
        break;
      }
    }
    if (!hasItem.value && value && key) {
      params[getSafeParamName(key)] = value;
      return true;
    } else if (value) {
      const matcher = new RegExp(`^${hasItem.value}$`);
      const matches = Array.isArray(value) ? value.slice(-1)[0].match(matcher) : value.match(matcher);
      if (matches) {
        if (Array.isArray(matches)) {
          if (matches.groups) {
            Object.keys(matches.groups).forEach((groupKey) => {
              params[groupKey] = matches.groups[groupKey];
            });
          } else if (hasItem.type === "host" && matches[0]) {
            params.host = matches[0];
          }
        }
        return true;
      }
    }
    return false;
  };
  const allMatch = has.every((item) => hasMatch(item)) && !missing.some((item) => hasMatch(item));
  if (allMatch) {
    return params;
  }
  return false;
}
function getSafeParamName(paramName) {
  let newParamName = "";
  for (let i = 0; i < paramName.length; i++) {
    const charCode = paramName.charCodeAt(i);
    if (charCode > 64 && charCode < 91 || // A-Z
    charCode > 96 && charCode < 123) {
      newParamName += paramName[i];
    }
  }
  return newParamName;
}
var decodeMaybeEncodedPath = (path) => {
  try {
    return decodeURIComponent(path);
  } catch {
    return path;
  }
};
function getMiddlewareRouteMatcher(matchers) {
  return (unsafePathname, req, query) => {
    const pathname = decodeMaybeEncodedPath(unsafePathname ?? "");
    for (const matcher of matchers) {
      const routeMatch = new RegExp(matcher.regexp).exec(pathname);
      if (!routeMatch) {
        continue;
      }
      if (matcher.has || matcher.missing) {
        const hasParams = matchHas(req, query, matcher.has, matcher.missing);
        if (!hasParams) {
          continue;
        }
      }
      return true;
    }
    return false;
  };
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/middleware.ts
var matchesMiddleware = getMiddlewareRouteMatcher(matchers_default || []);
async function handleMiddleware(request, context, nextHandler) {
  const url = new URL(request.url);
  const reqLogger = logger.withLogLevel(request.headers.has(InternalHeaders.NFDebugLogging) ? LogLevel.Debug : LogLevel.Log).withFields({
    url_path: url.pathname
  }).withRequestID(request.headers.get(InternalHeaders.NFRequestID));
  const { localizedUrl } = localizeRequest(url, next_config_default);
  if (!matchesMiddleware(localizedUrl.pathname, request, searchParamsToUrlQuery(url.searchParams))) {
    reqLogger.withFields({
      next_original_url: url,
      next_localized_url: localizedUrl.href
    }).debug("Aborting middleware due to runtime rules");
    return;
  }
  const nextRequest = buildNextRequest(request, context, next_config_default);
  try {
    const result = await nextHandler({
      request: nextRequest
    });
    const response = await buildResponse({
      context,
      logger: reqLogger,
      request,
      result,
      nextConfig: next_config_default
    });
    return response;
  } catch (error) {
    console.error(error);
    return new Response(error.message, {
      status: 500
    });
  }
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/server/middleware.js
import { AsyncLocalStorage } from "node:async_hooks";
import process from "node:process";
import * as BufferCompat from "node:buffer";
import * as EventsCompat from "node:events";
import * as AsyncHooksCompat from "node:async_hooks";
import * as AssertCompat from "node:assert";
import * as UtilCompat from "node:util";
globalThis.process = process;
globalThis.AsyncLocalStorage = AsyncLocalStorage;
globalThis.require = function nextRuntimeMinimalRequireShim(name) {
  switch (name.replace(/^node:/, "")) {
    case "buffer":
      return BufferCompat;
    case "events":
      return EventsCompat;
    case "async_hooks":
      return AsyncHooksCompat;
    case "assert":
      return AssertCompat;
    case "util":
      return UtilCompat;
    default:
      throw new ReferenceError(`require is not defined`);
  }
};
var _ENTRIES = {};
try {
  self._ENTRIES = _ENTRIES;
} catch {
}
process.env.__NEXT_BUILD_ID = "KQXmRJzHUxz5iqci8l0SA";
process.env.NEXT_SERVER_ACTIONS_ENCRYPTION_KEY = "EAErGDTWA+DKbp33jUX3t/AavO16ifzTG8Rxf7lik4w=";
process.env.__NEXT_PREVIEW_MODE_ID = "eb5c327f79bc6ead1039b7f606e69b86";
process.env.__NEXT_PREVIEW_MODE_SIGNING_KEY = "ece54b56032d2e5f268b78b12bc720c7ae04784fe5b8c55de94f2f0ac6ec234b";
process.env.__NEXT_PREVIEW_MODE_ENCRYPTION_KEY = "44ca15e7ff2ebb78d6c2b8e5f409d759b8103c4b2d8af8bf5efa745484878183";
(() => {
  "use strict";
  var a = {}, b = {};
  function c(d) {
    var e = b[d];
    if (void 0 !== e) return e.exports;
    var f = b[d] = {
      exports: {}
    }, g = true;
    try {
      a[d](f, f.exports, c), g = false;
    } finally {
      g && delete b[d];
    }
    return f.exports;
  }
  c.m = a, c.amdO = {}, (() => {
    var a2 = [];
    c.O = (b2, d, e, f) => {
      if (d) {
        f = f || 0;
        for (var g = a2.length; g > 0 && a2[g - 1][2] > f; g--) a2[g] = a2[g - 1];
        a2[g] = [
          d,
          e,
          f
        ];
        return;
      }
      for (var h = 1 / 0, g = 0; g < a2.length; g++) {
        for (var [d, e, f] = a2[g], i = true, j = 0; j < d.length; j++) (false & f || h >= f) && Object.keys(c.O).every((a3) => c.O[a3](d[j])) ? d.splice(j--, 1) : (i = false, f < h && (h = f));
        if (i) {
          a2.splice(g--, 1);
          var k = e();
          void 0 !== k && (b2 = k);
        }
      }
      return b2;
    };
  })(), c.n = (a2) => {
    var b2 = a2 && a2.__esModule ? () => a2.default : () => a2;
    return c.d(b2, {
      a: b2
    }), b2;
  }, c.d = (a2, b2) => {
    for (var d in b2) c.o(b2, d) && !c.o(a2, d) && Object.defineProperty(a2, d, {
      enumerable: true,
      get: b2[d]
    });
  }, c.g = function() {
    if ("object" == typeof globalThis) return globalThis;
    try {
      return this || Function("return this")();
    } catch (a2) {
      if ("object" == typeof window) return window;
    }
  }(), c.o = (a2, b2) => Object.prototype.hasOwnProperty.call(a2, b2), c.r = (a2) => {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(a2, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(a2, "__esModule", {
      value: true
    });
  }, (() => {
    var a2 = {
      149: 0
    };
    c.O.j = (b3) => 0 === a2[b3];
    var b2 = (b3, d2) => {
      var e, f, [g, h, i] = d2, j = 0;
      if (g.some((b4) => 0 !== a2[b4])) {
        for (e in h) c.o(h, e) && (c.m[e] = h[e]);
        if (i) var k = i(c);
      }
      for (b3 && b3(d2); j < g.length; j++) f = g[j], c.o(a2, f) && a2[f] && a2[f][0](), a2[f] = 0;
      return c.O(k);
    }, d = self.webpackChunk_N_E = self.webpackChunk_N_E || [];
    d.forEach(b2.bind(null, 0)), d.push = b2.bind(null, d.push.bind(d));
  })();
})();
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [
    751
  ],
  {
    165: (a, b, c) => {
      "use strict";
      var d = c(356).Buffer;
      Object.defineProperty(b, "__esModule", {
        value: true
      }), !function(a2, b2) {
        for (var c2 in b2) Object.defineProperty(a2, c2, {
          enumerable: true,
          get: b2[c2]
        });
      }(b, {
        handleFetch: function() {
          return h;
        },
        interceptFetch: function() {
          return i;
        },
        reader: function() {
          return f;
        }
      });
      let e = c(392), f = {
        url: (a2) => a2.url,
        header: (a2, b2) => a2.headers.get(b2)
      };
      async function g(a2, b2) {
        let { url: c2, method: e2, headers: f2, body: g2, cache: h2, credentials: i2, integrity: j, mode: k, redirect: l, referrer: m, referrerPolicy: n } = b2;
        return {
          testData: a2,
          api: "fetch",
          request: {
            url: c2,
            method: e2,
            headers: [
              ...Array.from(f2),
              [
                "next-test-stack",
                function() {
                  let a3 = (Error().stack ?? "").split("\n");
                  for (let b3 = 1; b3 < a3.length; b3++) if (a3[b3].length > 0) {
                    a3 = a3.slice(b3);
                    break;
                  }
                  return (a3 = (a3 = (a3 = a3.filter((a4) => !a4.includes("/next/dist/"))).slice(0, 5)).map((a4) => a4.replace("webpack-internal:///(rsc)/", "").trim())).join("    ");
                }()
              ]
            ],
            body: g2 ? d.from(await b2.arrayBuffer()).toString("base64") : null,
            cache: h2,
            credentials: i2,
            integrity: j,
            mode: k,
            redirect: l,
            referrer: m,
            referrerPolicy: n
          }
        };
      }
      async function h(a2, b2) {
        let c2 = (0, e.getTestReqInfo)(b2, f);
        if (!c2) return a2(b2);
        let { testData: h2, proxyPort: i2 } = c2, j = await g(h2, b2), k = await a2(`http://localhost:${i2}`, {
          method: "POST",
          body: JSON.stringify(j),
          next: {
            internal: true
          }
        });
        if (!k.ok) throw Object.defineProperty(Error(`Proxy request failed: ${k.status}`), "__NEXT_ERROR_CODE", {
          value: "E146",
          enumerable: false,
          configurable: true
        });
        let l = await k.json(), { api: m } = l;
        switch (m) {
          case "continue":
            return a2(b2);
          case "abort":
          case "unhandled":
            throw Object.defineProperty(Error(`Proxy request aborted [${b2.method} ${b2.url}]`), "__NEXT_ERROR_CODE", {
              value: "E145",
              enumerable: false,
              configurable: true
            });
          case "fetch":
            let { status: n, headers: o, body: p } = l.response;
            return new Response(p ? d.from(p, "base64") : null, {
              status: n,
              headers: new Headers(o)
            });
          default:
            return m;
        }
      }
      function i(a2) {
        return c.g.fetch = function(b2, c2) {
          var d2;
          return (null == c2 || null == (d2 = c2.next) ? void 0 : d2.internal) ? a2(b2, c2) : h(a2, new Request(b2, c2));
        }, () => {
          c.g.fetch = a2;
        };
      }
    },
    213: (a) => {
      (() => {
        "use strict";
        var b = {
          993: (a2) => {
            var b2 = Object.prototype.hasOwnProperty, c2 = "~";
            function d2() {
            }
            function e2(a3, b3, c3) {
              this.fn = a3, this.context = b3, this.once = c3 || false;
            }
            function f(a3, b3, d3, f2, g2) {
              if ("function" != typeof d3) throw TypeError("The listener must be a function");
              var h2 = new e2(d3, f2 || a3, g2), i = c2 ? c2 + b3 : b3;
              return a3._events[i] ? a3._events[i].fn ? a3._events[i] = [
                a3._events[i],
                h2
              ] : a3._events[i].push(h2) : (a3._events[i] = h2, a3._eventsCount++), a3;
            }
            function g(a3, b3) {
              0 == --a3._eventsCount ? a3._events = new d2() : delete a3._events[b3];
            }
            function h() {
              this._events = new d2(), this._eventsCount = 0;
            }
            Object.create && (d2.prototype = /* @__PURE__ */ Object.create(null), new d2().__proto__ || (c2 = false)), h.prototype.eventNames = function() {
              var a3, d3, e3 = [];
              if (0 === this._eventsCount) return e3;
              for (d3 in a3 = this._events) b2.call(a3, d3) && e3.push(c2 ? d3.slice(1) : d3);
              return Object.getOwnPropertySymbols ? e3.concat(Object.getOwnPropertySymbols(a3)) : e3;
            }, h.prototype.listeners = function(a3) {
              var b3 = c2 ? c2 + a3 : a3, d3 = this._events[b3];
              if (!d3) return [];
              if (d3.fn) return [
                d3.fn
              ];
              for (var e3 = 0, f2 = d3.length, g2 = Array(f2); e3 < f2; e3++) g2[e3] = d3[e3].fn;
              return g2;
            }, h.prototype.listenerCount = function(a3) {
              var b3 = c2 ? c2 + a3 : a3, d3 = this._events[b3];
              return d3 ? d3.fn ? 1 : d3.length : 0;
            }, h.prototype.emit = function(a3, b3, d3, e3, f2, g2) {
              var h2 = c2 ? c2 + a3 : a3;
              if (!this._events[h2]) return false;
              var i, j, k = this._events[h2], l = arguments.length;
              if (k.fn) {
                switch (k.once && this.removeListener(a3, k.fn, void 0, true), l) {
                  case 1:
                    return k.fn.call(k.context), true;
                  case 2:
                    return k.fn.call(k.context, b3), true;
                  case 3:
                    return k.fn.call(k.context, b3, d3), true;
                  case 4:
                    return k.fn.call(k.context, b3, d3, e3), true;
                  case 5:
                    return k.fn.call(k.context, b3, d3, e3, f2), true;
                  case 6:
                    return k.fn.call(k.context, b3, d3, e3, f2, g2), true;
                }
                for (j = 1, i = Array(l - 1); j < l; j++) i[j - 1] = arguments[j];
                k.fn.apply(k.context, i);
              } else {
                var m, n = k.length;
                for (j = 0; j < n; j++) switch (k[j].once && this.removeListener(a3, k[j].fn, void 0, true), l) {
                  case 1:
                    k[j].fn.call(k[j].context);
                    break;
                  case 2:
                    k[j].fn.call(k[j].context, b3);
                    break;
                  case 3:
                    k[j].fn.call(k[j].context, b3, d3);
                    break;
                  case 4:
                    k[j].fn.call(k[j].context, b3, d3, e3);
                    break;
                  default:
                    if (!i) for (m = 1, i = Array(l - 1); m < l; m++) i[m - 1] = arguments[m];
                    k[j].fn.apply(k[j].context, i);
                }
              }
              return true;
            }, h.prototype.on = function(a3, b3, c3) {
              return f(this, a3, b3, c3, false);
            }, h.prototype.once = function(a3, b3, c3) {
              return f(this, a3, b3, c3, true);
            }, h.prototype.removeListener = function(a3, b3, d3, e3) {
              var f2 = c2 ? c2 + a3 : a3;
              if (!this._events[f2]) return this;
              if (!b3) return g(this, f2), this;
              var h2 = this._events[f2];
              if (h2.fn) h2.fn !== b3 || e3 && !h2.once || d3 && h2.context !== d3 || g(this, f2);
              else {
                for (var i = 0, j = [], k = h2.length; i < k; i++) (h2[i].fn !== b3 || e3 && !h2[i].once || d3 && h2[i].context !== d3) && j.push(h2[i]);
                j.length ? this._events[f2] = 1 === j.length ? j[0] : j : g(this, f2);
              }
              return this;
            }, h.prototype.removeAllListeners = function(a3) {
              var b3;
              return a3 ? (b3 = c2 ? c2 + a3 : a3, this._events[b3] && g(this, b3)) : (this._events = new d2(), this._eventsCount = 0), this;
            }, h.prototype.off = h.prototype.removeListener, h.prototype.addListener = h.prototype.on, h.prefixed = c2, h.EventEmitter = h, a2.exports = h;
          },
          213: (a2) => {
            a2.exports = (a3, b2) => (b2 = b2 || (() => {
            }), a3.then((a4) => new Promise((a5) => {
              a5(b2());
            }).then(() => a4), (a4) => new Promise((a5) => {
              a5(b2());
            }).then(() => {
              throw a4;
            })));
          },
          574: (a2, b2) => {
            Object.defineProperty(b2, "__esModule", {
              value: true
            }), b2.default = function(a3, b3, c2) {
              let d2 = 0, e2 = a3.length;
              for (; e2 > 0; ) {
                let f = e2 / 2 | 0, g = d2 + f;
                0 >= c2(a3[g], b3) ? (d2 = ++g, e2 -= f + 1) : e2 = f;
              }
              return d2;
            };
          },
          821: (a2, b2, c2) => {
            Object.defineProperty(b2, "__esModule", {
              value: true
            });
            let d2 = c2(574);
            class e2 {
              constructor() {
                this._queue = [];
              }
              enqueue(a3, b3) {
                let c3 = {
                  priority: (b3 = Object.assign({
                    priority: 0
                  }, b3)).priority,
                  run: a3
                };
                if (this.size && this._queue[this.size - 1].priority >= b3.priority) return void this._queue.push(c3);
                let e3 = d2.default(this._queue, c3, (a4, b4) => b4.priority - a4.priority);
                this._queue.splice(e3, 0, c3);
              }
              dequeue() {
                let a3 = this._queue.shift();
                return null == a3 ? void 0 : a3.run;
              }
              filter(a3) {
                return this._queue.filter((b3) => b3.priority === a3.priority).map((a4) => a4.run);
              }
              get size() {
                return this._queue.length;
              }
            }
            b2.default = e2;
          },
          816: (a2, b2, c2) => {
            let d2 = c2(213);
            class e2 extends Error {
              constructor(a3) {
                super(a3), this.name = "TimeoutError";
              }
            }
            let f = (a3, b3, c3) => new Promise((f2, g) => {
              if ("number" != typeof b3 || b3 < 0) throw TypeError("Expected `milliseconds` to be a positive number");
              if (b3 === 1 / 0) return void f2(a3);
              let h = setTimeout(() => {
                if ("function" == typeof c3) {
                  try {
                    f2(c3());
                  } catch (a4) {
                    g(a4);
                  }
                  return;
                }
                let d3 = "string" == typeof c3 ? c3 : `Promise timed out after ${b3} milliseconds`, h2 = c3 instanceof Error ? c3 : new e2(d3);
                "function" == typeof a3.cancel && a3.cancel(), g(h2);
              }, b3);
              d2(a3.then(f2, g), () => {
                clearTimeout(h);
              });
            });
            a2.exports = f, a2.exports.default = f, a2.exports.TimeoutError = e2;
          }
        }, c = {};
        function d(a2) {
          var e2 = c[a2];
          if (void 0 !== e2) return e2.exports;
          var f = c[a2] = {
            exports: {}
          }, g = true;
          try {
            b[a2](f, f.exports, d), g = false;
          } finally {
            g && delete c[a2];
          }
          return f.exports;
        }
        d.ab = "//";
        var e = {};
        (() => {
          Object.defineProperty(e, "__esModule", {
            value: true
          });
          let a2 = d(993), b2 = d(816), c2 = d(821), f = () => {
          }, g = new b2.TimeoutError();
          class h extends a2 {
            constructor(a3) {
              var b3, d2, e2, g2;
              if (super(), this._intervalCount = 0, this._intervalEnd = 0, this._pendingCount = 0, this._resolveEmpty = f, this._resolveIdle = f, !("number" == typeof (a3 = Object.assign({
                carryoverConcurrencyCount: false,
                intervalCap: 1 / 0,
                interval: 0,
                concurrency: 1 / 0,
                autoStart: true,
                queueClass: c2.default
              }, a3)).intervalCap && a3.intervalCap >= 1)) throw TypeError(`Expected \`intervalCap\` to be a number from 1 and up, got \`${null != (d2 = null == (b3 = a3.intervalCap) ? void 0 : b3.toString()) ? d2 : ""}\` (${typeof a3.intervalCap})`);
              if (void 0 === a3.interval || !(Number.isFinite(a3.interval) && a3.interval >= 0)) throw TypeError(`Expected \`interval\` to be a finite number >= 0, got \`${null != (g2 = null == (e2 = a3.interval) ? void 0 : e2.toString()) ? g2 : ""}\` (${typeof a3.interval})`);
              this._carryoverConcurrencyCount = a3.carryoverConcurrencyCount, this._isIntervalIgnored = a3.intervalCap === 1 / 0 || 0 === a3.interval, this._intervalCap = a3.intervalCap, this._interval = a3.interval, this._queue = new a3.queueClass(), this._queueClass = a3.queueClass, this.concurrency = a3.concurrency, this._timeout = a3.timeout, this._throwOnTimeout = true === a3.throwOnTimeout, this._isPaused = false === a3.autoStart;
            }
            get _doesIntervalAllowAnother() {
              return this._isIntervalIgnored || this._intervalCount < this._intervalCap;
            }
            get _doesConcurrentAllowAnother() {
              return this._pendingCount < this._concurrency;
            }
            _next() {
              this._pendingCount--, this._tryToStartAnother(), this.emit("next");
            }
            _resolvePromises() {
              this._resolveEmpty(), this._resolveEmpty = f, 0 === this._pendingCount && (this._resolveIdle(), this._resolveIdle = f, this.emit("idle"));
            }
            _onResumeInterval() {
              this._onInterval(), this._initializeIntervalIfNeeded(), this._timeoutId = void 0;
            }
            _isIntervalPaused() {
              let a3 = Date.now();
              if (void 0 === this._intervalId) {
                let b3 = this._intervalEnd - a3;
                if (!(b3 < 0)) return void 0 === this._timeoutId && (this._timeoutId = setTimeout(() => {
                  this._onResumeInterval();
                }, b3)), true;
                this._intervalCount = this._carryoverConcurrencyCount ? this._pendingCount : 0;
              }
              return false;
            }
            _tryToStartAnother() {
              if (0 === this._queue.size) return this._intervalId && clearInterval(this._intervalId), this._intervalId = void 0, this._resolvePromises(), false;
              if (!this._isPaused) {
                let a3 = !this._isIntervalPaused();
                if (this._doesIntervalAllowAnother && this._doesConcurrentAllowAnother) {
                  let b3 = this._queue.dequeue();
                  return !!b3 && (this.emit("active"), b3(), a3 && this._initializeIntervalIfNeeded(), true);
                }
              }
              return false;
            }
            _initializeIntervalIfNeeded() {
              this._isIntervalIgnored || void 0 !== this._intervalId || (this._intervalId = setInterval(() => {
                this._onInterval();
              }, this._interval), this._intervalEnd = Date.now() + this._interval);
            }
            _onInterval() {
              0 === this._intervalCount && 0 === this._pendingCount && this._intervalId && (clearInterval(this._intervalId), this._intervalId = void 0), this._intervalCount = this._carryoverConcurrencyCount ? this._pendingCount : 0, this._processQueue();
            }
            _processQueue() {
              for (; this._tryToStartAnother(); ) ;
            }
            get concurrency() {
              return this._concurrency;
            }
            set concurrency(a3) {
              if (!("number" == typeof a3 && a3 >= 1)) throw TypeError(`Expected \`concurrency\` to be a number from 1 and up, got \`${a3}\` (${typeof a3})`);
              this._concurrency = a3, this._processQueue();
            }
            async add(a3, c3 = {}) {
              return new Promise((d2, e2) => {
                let f2 = async () => {
                  this._pendingCount++, this._intervalCount++;
                  try {
                    let f3 = void 0 === this._timeout && void 0 === c3.timeout ? a3() : b2.default(Promise.resolve(a3()), void 0 === c3.timeout ? this._timeout : c3.timeout, () => {
                      (void 0 === c3.throwOnTimeout ? this._throwOnTimeout : c3.throwOnTimeout) && e2(g);
                    });
                    d2(await f3);
                  } catch (a4) {
                    e2(a4);
                  }
                  this._next();
                };
                this._queue.enqueue(f2, c3), this._tryToStartAnother(), this.emit("add");
              });
            }
            async addAll(a3, b3) {
              return Promise.all(a3.map(async (a4) => this.add(a4, b3)));
            }
            start() {
              return this._isPaused && (this._isPaused = false, this._processQueue()), this;
            }
            pause() {
              this._isPaused = true;
            }
            clear() {
              this._queue = new this._queueClass();
            }
            async onEmpty() {
              if (0 !== this._queue.size) return new Promise((a3) => {
                let b3 = this._resolveEmpty;
                this._resolveEmpty = () => {
                  b3(), a3();
                };
              });
            }
            async onIdle() {
              if (0 !== this._pendingCount || 0 !== this._queue.size) return new Promise((a3) => {
                let b3 = this._resolveIdle;
                this._resolveIdle = () => {
                  b3(), a3();
                };
              });
            }
            get size() {
              return this._queue.size;
            }
            sizeBy(a3) {
              return this._queue.filter(a3).length;
            }
            get pending() {
              return this._pendingCount;
            }
            get isPaused() {
              return this._isPaused;
            }
            get timeout() {
              return this._timeout;
            }
            set timeout(a3) {
              this._timeout = a3;
            }
          }
          e.default = h;
        })(), a.exports = e;
      })();
    },
    356: (a) => {
      "use strict";
      a.exports = __require("node:buffer");
    },
    392: (a, b, c) => {
      "use strict";
      Object.defineProperty(b, "__esModule", {
        value: true
      }), !function(a2, b2) {
        for (var c2 in b2) Object.defineProperty(a2, c2, {
          enumerable: true,
          get: b2[c2]
        });
      }(b, {
        getTestReqInfo: function() {
          return g;
        },
        withRequest: function() {
          return f;
        }
      });
      let d = new (c(521)).AsyncLocalStorage();
      function e(a2, b2) {
        let c2 = b2.header(a2, "next-test-proxy-port");
        if (!c2) return;
        let d2 = b2.url(a2);
        return {
          url: d2,
          proxyPort: Number(c2),
          testData: b2.header(a2, "next-test-data") || ""
        };
      }
      function f(a2, b2, c2) {
        let f2 = e(a2, b2);
        return f2 ? d.run(f2, c2) : c2();
      }
      function g(a2, b2) {
        let c2 = d.getStore();
        return c2 || (a2 && b2 ? e(a2, b2) : void 0);
      }
    },
    440: (a, b) => {
      "use strict";
      Symbol.for("react.transitional.element"), Symbol.for("react.portal"), Symbol.for("react.fragment"), Symbol.for("react.strict_mode"), Symbol.for("react.profiler"), Symbol.for("react.forward_ref"), Symbol.for("react.suspense"), Symbol.for("react.memo"), Symbol.for("react.lazy"), Symbol.iterator;
      Object.prototype.hasOwnProperty, Object.assign;
    },
    443: (a) => {
      "use strict";
      var b = Object.defineProperty, c = Object.getOwnPropertyDescriptor, d = Object.getOwnPropertyNames, e = Object.prototype.hasOwnProperty, f = {};
      function g(a2) {
        var b2;
        let c2 = [
          "path" in a2 && a2.path && `Path=${a2.path}`,
          "expires" in a2 && (a2.expires || 0 === a2.expires) && `Expires=${("number" == typeof a2.expires ? new Date(a2.expires) : a2.expires).toUTCString()}`,
          "maxAge" in a2 && "number" == typeof a2.maxAge && `Max-Age=${a2.maxAge}`,
          "domain" in a2 && a2.domain && `Domain=${a2.domain}`,
          "secure" in a2 && a2.secure && "Secure",
          "httpOnly" in a2 && a2.httpOnly && "HttpOnly",
          "sameSite" in a2 && a2.sameSite && `SameSite=${a2.sameSite}`,
          "partitioned" in a2 && a2.partitioned && "Partitioned",
          "priority" in a2 && a2.priority && `Priority=${a2.priority}`
        ].filter(Boolean), d2 = `${a2.name}=${encodeURIComponent(null != (b2 = a2.value) ? b2 : "")}`;
        return 0 === c2.length ? d2 : `${d2}; ${c2.join("; ")}`;
      }
      function h(a2) {
        let b2 = /* @__PURE__ */ new Map();
        for (let c2 of a2.split(/; */)) {
          if (!c2) continue;
          let a3 = c2.indexOf("=");
          if (-1 === a3) {
            b2.set(c2, "true");
            continue;
          }
          let [d2, e2] = [
            c2.slice(0, a3),
            c2.slice(a3 + 1)
          ];
          try {
            b2.set(d2, decodeURIComponent(null != e2 ? e2 : "true"));
          } catch {
          }
        }
        return b2;
      }
      function i(a2) {
        if (!a2) return;
        let [[b2, c2], ...d2] = h(a2), { domain: e2, expires: f2, httponly: g2, maxage: i2, path: l2, samesite: m2, secure: n, partitioned: o, priority: p } = Object.fromEntries(d2.map(([a3, b3]) => [
          a3.toLowerCase().replace(/-/g, ""),
          b3
        ]));
        {
          var q, r, s = {
            name: b2,
            value: decodeURIComponent(c2),
            domain: e2,
            ...f2 && {
              expires: new Date(f2)
            },
            ...g2 && {
              httpOnly: true
            },
            ..."string" == typeof i2 && {
              maxAge: Number(i2)
            },
            path: l2,
            ...m2 && {
              sameSite: j.includes(q = (q = m2).toLowerCase()) ? q : void 0
            },
            ...n && {
              secure: true
            },
            ...p && {
              priority: k.includes(r = (r = p).toLowerCase()) ? r : void 0
            },
            ...o && {
              partitioned: true
            }
          };
          let a3 = {};
          for (let b3 in s) s[b3] && (a3[b3] = s[b3]);
          return a3;
        }
      }
      ((a2, c2) => {
        for (var d2 in c2) b(a2, d2, {
          get: c2[d2],
          enumerable: true
        });
      })(f, {
        RequestCookies: () => l,
        ResponseCookies: () => m,
        parseCookie: () => h,
        parseSetCookie: () => i,
        stringifyCookie: () => g
      }), a.exports = ((a2, f2, g2, h2) => {
        if (f2 && "object" == typeof f2 || "function" == typeof f2) for (let i2 of d(f2)) e.call(a2, i2) || i2 === g2 || b(a2, i2, {
          get: () => f2[i2],
          enumerable: !(h2 = c(f2, i2)) || h2.enumerable
        });
        return a2;
      })(b({}, "__esModule", {
        value: true
      }), f);
      var j = [
        "strict",
        "lax",
        "none"
      ], k = [
        "low",
        "medium",
        "high"
      ], l = class {
        constructor(a2) {
          this._parsed = /* @__PURE__ */ new Map(), this._headers = a2;
          let b2 = a2.get("cookie");
          if (b2) for (let [a3, c2] of h(b2)) this._parsed.set(a3, {
            name: a3,
            value: c2
          });
        }
        [Symbol.iterator]() {
          return this._parsed[Symbol.iterator]();
        }
        get size() {
          return this._parsed.size;
        }
        get(...a2) {
          let b2 = "string" == typeof a2[0] ? a2[0] : a2[0].name;
          return this._parsed.get(b2);
        }
        getAll(...a2) {
          var b2;
          let c2 = Array.from(this._parsed);
          if (!a2.length) return c2.map(([a3, b3]) => b3);
          let d2 = "string" == typeof a2[0] ? a2[0] : null == (b2 = a2[0]) ? void 0 : b2.name;
          return c2.filter(([a3]) => a3 === d2).map(([a3, b3]) => b3);
        }
        has(a2) {
          return this._parsed.has(a2);
        }
        set(...a2) {
          let [b2, c2] = 1 === a2.length ? [
            a2[0].name,
            a2[0].value
          ] : a2, d2 = this._parsed;
          return d2.set(b2, {
            name: b2,
            value: c2
          }), this._headers.set("cookie", Array.from(d2).map(([a3, b3]) => g(b3)).join("; ")), this;
        }
        delete(a2) {
          let b2 = this._parsed, c2 = Array.isArray(a2) ? a2.map((a3) => b2.delete(a3)) : b2.delete(a2);
          return this._headers.set("cookie", Array.from(b2).map(([a3, b3]) => g(b3)).join("; ")), c2;
        }
        clear() {
          return this.delete(Array.from(this._parsed.keys())), this;
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return `RequestCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
        }
        toString() {
          return [
            ...this._parsed.values()
          ].map((a2) => `${a2.name}=${encodeURIComponent(a2.value)}`).join("; ");
        }
      }, m = class {
        constructor(a2) {
          var b2, c2, d2;
          this._parsed = /* @__PURE__ */ new Map(), this._headers = a2;
          let e2 = null != (d2 = null != (c2 = null == (b2 = a2.getSetCookie) ? void 0 : b2.call(a2)) ? c2 : a2.get("set-cookie")) ? d2 : [];
          for (let a3 of Array.isArray(e2) ? e2 : function(a4) {
            if (!a4) return [];
            var b3, c3, d3, e3, f2, g2 = [], h2 = 0;
            function i2() {
              for (; h2 < a4.length && /\s/.test(a4.charAt(h2)); ) h2 += 1;
              return h2 < a4.length;
            }
            for (; h2 < a4.length; ) {
              for (b3 = h2, f2 = false; i2(); ) if ("," === (c3 = a4.charAt(h2))) {
                for (d3 = h2, h2 += 1, i2(), e3 = h2; h2 < a4.length && "=" !== (c3 = a4.charAt(h2)) && ";" !== c3 && "," !== c3; ) h2 += 1;
                h2 < a4.length && "=" === a4.charAt(h2) ? (f2 = true, h2 = e3, g2.push(a4.substring(b3, d3)), b3 = h2) : h2 = d3 + 1;
              } else h2 += 1;
              (!f2 || h2 >= a4.length) && g2.push(a4.substring(b3, a4.length));
            }
            return g2;
          }(e2)) {
            let b3 = i(a3);
            b3 && this._parsed.set(b3.name, b3);
          }
        }
        get(...a2) {
          let b2 = "string" == typeof a2[0] ? a2[0] : a2[0].name;
          return this._parsed.get(b2);
        }
        getAll(...a2) {
          var b2;
          let c2 = Array.from(this._parsed.values());
          if (!a2.length) return c2;
          let d2 = "string" == typeof a2[0] ? a2[0] : null == (b2 = a2[0]) ? void 0 : b2.name;
          return c2.filter((a3) => a3.name === d2);
        }
        has(a2) {
          return this._parsed.has(a2);
        }
        set(...a2) {
          let [b2, c2, d2] = 1 === a2.length ? [
            a2[0].name,
            a2[0].value,
            a2[0]
          ] : a2, e2 = this._parsed;
          return e2.set(b2, function(a3 = {
            name: "",
            value: ""
          }) {
            return "number" == typeof a3.expires && (a3.expires = new Date(a3.expires)), a3.maxAge && (a3.expires = new Date(Date.now() + 1e3 * a3.maxAge)), (null === a3.path || void 0 === a3.path) && (a3.path = "/"), a3;
          }({
            name: b2,
            value: c2,
            ...d2
          })), function(a3, b3) {
            for (let [, c3] of (b3.delete("set-cookie"), a3)) {
              let a4 = g(c3);
              b3.append("set-cookie", a4);
            }
          }(e2, this._headers), this;
        }
        delete(...a2) {
          let [b2, c2] = "string" == typeof a2[0] ? [
            a2[0]
          ] : [
            a2[0].name,
            a2[0]
          ];
          return this.set({
            ...c2,
            name: b2,
            value: "",
            expires: /* @__PURE__ */ new Date(0)
          });
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return `ResponseCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
        }
        toString() {
          return [
            ...this._parsed.values()
          ].map(g).join("; ");
        }
      };
    },
    449: (a, b, c) => {
      var d;
      (() => {
        var e = {
          226: function(e2, f2) {
            !function(g2, h) {
              "use strict";
              var i = "function", j = "undefined", k = "object", l = "string", m = "major", n = "model", o = "name", p = "type", q = "vendor", r = "version", s = "architecture", t = "console", u = "mobile", v = "tablet", w = "smarttv", x = "wearable", y = "embedded", z = "Amazon", A = "Apple", B = "ASUS", C = "BlackBerry", D = "Browser", E = "Chrome", F = "Firefox", G = "Google", H = "Huawei", I = "Microsoft", J = "Motorola", K = "Opera", L = "Samsung", M = "Sharp", N = "Sony", O = "Xiaomi", P = "Zebra", Q = "Facebook", R = "Chromium OS", S = "Mac OS", T = function(a2, b2) {
                var c2 = {};
                for (var d2 in a2) b2[d2] && b2[d2].length % 2 == 0 ? c2[d2] = b2[d2].concat(a2[d2]) : c2[d2] = a2[d2];
                return c2;
              }, U = function(a2) {
                for (var b2 = {}, c2 = 0; c2 < a2.length; c2++) b2[a2[c2].toUpperCase()] = a2[c2];
                return b2;
              }, V = function(a2, b2) {
                return typeof a2 === l && -1 !== W(b2).indexOf(W(a2));
              }, W = function(a2) {
                return a2.toLowerCase();
              }, X = function(a2, b2) {
                if (typeof a2 === l) return a2 = a2.replace(/^\s\s*/, ""), typeof b2 === j ? a2 : a2.substring(0, 350);
              }, Y = function(a2, b2) {
                for (var c2, d2, e3, f3, g3, j2, l2 = 0; l2 < b2.length && !g3; ) {
                  var m2 = b2[l2], n2 = b2[l2 + 1];
                  for (c2 = d2 = 0; c2 < m2.length && !g3 && m2[c2]; ) if (g3 = m2[c2++].exec(a2)) for (e3 = 0; e3 < n2.length; e3++) j2 = g3[++d2], typeof (f3 = n2[e3]) === k && f3.length > 0 ? 2 === f3.length ? typeof f3[1] == i ? this[f3[0]] = f3[1].call(this, j2) : this[f3[0]] = f3[1] : 3 === f3.length ? typeof f3[1] !== i || f3[1].exec && f3[1].test ? this[f3[0]] = j2 ? j2.replace(f3[1], f3[2]) : void 0 : this[f3[0]] = j2 ? f3[1].call(this, j2, f3[2]) : void 0 : 4 === f3.length && (this[f3[0]] = j2 ? f3[3].call(this, j2.replace(f3[1], f3[2])) : h) : this[f3] = j2 || h;
                  l2 += 2;
                }
              }, Z = function(a2, b2) {
                for (var c2 in b2) if (typeof b2[c2] === k && b2[c2].length > 0) {
                  for (var d2 = 0; d2 < b2[c2].length; d2++) if (V(b2[c2][d2], a2)) return "?" === c2 ? h : c2;
                } else if (V(b2[c2], a2)) return "?" === c2 ? h : c2;
                return a2;
              }, $ = {
                ME: "4.90",
                "NT 3.11": "NT3.51",
                "NT 4.0": "NT4.0",
                2e3: "NT 5.0",
                XP: [
                  "NT 5.1",
                  "NT 5.2"
                ],
                Vista: "NT 6.0",
                7: "NT 6.1",
                8: "NT 6.2",
                8.1: "NT 6.3",
                10: [
                  "NT 6.4",
                  "NT 10.0"
                ],
                RT: "ARM"
              }, _ = {
                browser: [
                  [
                    /\b(?:crmo|crios)\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Chrome"
                    ]
                  ],
                  [
                    /edg(?:e|ios|a)?\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Edge"
                    ]
                  ],
                  [
                    /(opera mini)\/([-\w\.]+)/i,
                    /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                    /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /opios[\/ ]+([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      K + " Mini"
                    ]
                  ],
                  [
                    /\bopr\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      K
                    ]
                  ],
                  [
                    /(kindle)\/([\w\.]+)/i,
                    /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,
                    /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,
                    /(ba?idubrowser)[\/ ]?([\w\.]+)/i,
                    /(?:ms|\()(ie) ([\w\.]+)/i,
                    /(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,
                    /(heytap|ovi)browser\/([\d\.]+)/i,
                    /(weibo)__([\d\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "UC" + D
                    ]
                  ],
                  [
                    /microm.+\bqbcore\/([\w\.]+)/i,
                    /\bqbcore\/([\w\.]+).+microm/i
                  ],
                  [
                    r,
                    [
                      o,
                      "WeChat(Win) Desktop"
                    ]
                  ],
                  [
                    /micromessenger\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "WeChat"
                    ]
                  ],
                  [
                    /konqueror\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Konqueror"
                    ]
                  ],
                  [
                    /trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i
                  ],
                  [
                    r,
                    [
                      o,
                      "IE"
                    ]
                  ],
                  [
                    /ya(?:search)?browser\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Yandex"
                    ]
                  ],
                  [
                    /(avast|avg)\/([\w\.]+)/i
                  ],
                  [
                    [
                      o,
                      /(.+)/,
                      "$1 Secure " + D
                    ],
                    r
                  ],
                  [
                    /\bfocus\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      F + " Focus"
                    ]
                  ],
                  [
                    /\bopt\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      K + " Touch"
                    ]
                  ],
                  [
                    /coc_coc\w+\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Coc Coc"
                    ]
                  ],
                  [
                    /dolfin\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Dolphin"
                    ]
                  ],
                  [
                    /coast\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      K + " Coast"
                    ]
                  ],
                  [
                    /miuibrowser\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "MIUI " + D
                    ]
                  ],
                  [
                    /fxios\/([-\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      F
                    ]
                  ],
                  [
                    /\bqihu|(qi?ho?o?|360)browser/i
                  ],
                  [
                    [
                      o,
                      "360 " + D
                    ]
                  ],
                  [
                    /(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i
                  ],
                  [
                    [
                      o,
                      /(.+)/,
                      "$1 " + D
                    ],
                    r
                  ],
                  [
                    /(comodo_dragon)\/([\w\.]+)/i
                  ],
                  [
                    [
                      o,
                      /_/g,
                      " "
                    ],
                    r
                  ],
                  [
                    /(electron)\/([\w\.]+) safari/i,
                    /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                    /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(metasr)[\/ ]?([\w\.]+)/i,
                    /(lbbrowser)/i,
                    /\[(linkedin)app\]/i
                  ],
                  [
                    o
                  ],
                  [
                    /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i
                  ],
                  [
                    [
                      o,
                      Q
                    ],
                    r
                  ],
                  [
                    /(kakao(?:talk|story))[\/ ]([\w\.]+)/i,
                    /(naver)\(.*?(\d+\.[\w\.]+).*\)/i,
                    /safari (line)\/([\w\.]+)/i,
                    /\b(line)\/([\w\.]+)\/iab/i,
                    /(chromium|instagram)[\/ ]([-\w\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /\bgsa\/([\w\.]+) .*safari\//i
                  ],
                  [
                    r,
                    [
                      o,
                      "GSA"
                    ]
                  ],
                  [
                    /musical_ly(?:.+app_?version\/|_)([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "TikTok"
                    ]
                  ],
                  [
                    /headlesschrome(?:\/([\w\.]+)| )/i
                  ],
                  [
                    r,
                    [
                      o,
                      E + " Headless"
                    ]
                  ],
                  [
                    / wv\).+(chrome)\/([\w\.]+)/i
                  ],
                  [
                    [
                      o,
                      E + " WebView"
                    ],
                    r
                  ],
                  [
                    /droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Android " + D
                    ]
                  ],
                  [
                    /(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Mobile Safari"
                    ]
                  ],
                  [
                    /version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i
                  ],
                  [
                    r,
                    o
                  ],
                  [
                    /webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i
                  ],
                  [
                    o,
                    [
                      r,
                      Z,
                      {
                        "1.0": "/8",
                        1.2: "/1",
                        1.3: "/3",
                        "2.0": "/412",
                        "2.0.2": "/416",
                        "2.0.3": "/417",
                        "2.0.4": "/419",
                        "?": "/"
                      }
                    ]
                  ],
                  [
                    /(webkit|khtml)\/([\w\.]+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(navigator|netscape\d?)\/([-\w\.]+)/i
                  ],
                  [
                    [
                      o,
                      "Netscape"
                    ],
                    r
                  ],
                  [
                    /mobile vr; rv:([\w\.]+)\).+firefox/i
                  ],
                  [
                    r,
                    [
                      o,
                      F + " Reality"
                    ]
                  ],
                  [
                    /ekiohf.+(flow)\/([\w\.]+)/i,
                    /(swiftfox)/i,
                    /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                    /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                    /(firefox)\/([\w\.]+)/i,
                    /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                    /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                    /(links) \(([\w\.]+)/i,
                    /panasonic;(viera)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(cobalt)\/([\w\.]+)/i
                  ],
                  [
                    o,
                    [
                      r,
                      /master.|lts./,
                      ""
                    ]
                  ]
                ],
                cpu: [
                  [
                    /(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i
                  ],
                  [
                    [
                      s,
                      "amd64"
                    ]
                  ],
                  [
                    /(ia32(?=;))/i
                  ],
                  [
                    [
                      s,
                      W
                    ]
                  ],
                  [
                    /((?:i[346]|x)86)[;\)]/i
                  ],
                  [
                    [
                      s,
                      "ia32"
                    ]
                  ],
                  [
                    /\b(aarch64|arm(v?8e?l?|_?64))\b/i
                  ],
                  [
                    [
                      s,
                      "arm64"
                    ]
                  ],
                  [
                    /\b(arm(?:v[67])?ht?n?[fl]p?)\b/i
                  ],
                  [
                    [
                      s,
                      "armhf"
                    ]
                  ],
                  [
                    /windows (ce|mobile); ppc;/i
                  ],
                  [
                    [
                      s,
                      "arm"
                    ]
                  ],
                  [
                    /((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i
                  ],
                  [
                    [
                      s,
                      /ower/,
                      "",
                      W
                    ]
                  ],
                  [
                    /(sun4\w)[;\)]/i
                  ],
                  [
                    [
                      s,
                      "sparc"
                    ]
                  ],
                  [
                    /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i
                  ],
                  [
                    [
                      s,
                      W
                    ]
                  ]
                ],
                device: [
                  [
                    /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i
                  ],
                  [
                    n,
                    [
                      q,
                      L
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,
                    /samsung[- ]([-\w]+)/i,
                    /sec-(sgh\w+)/i
                  ],
                  [
                    n,
                    [
                      q,
                      L
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i
                  ],
                  [
                    n,
                    [
                      q,
                      A
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\((ipad);[-\w\),; ]+apple/i,
                    /applecoremedia\/[\w\.]+ \((ipad)/i,
                    /\b(ipad)\d\d?,\d\d?[;\]].+ios/i
                  ],
                  [
                    n,
                    [
                      q,
                      A
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(macintosh);/i
                  ],
                  [
                    n,
                    [
                      q,
                      A
                    ]
                  ],
                  [
                    /\b(sh-?[altvz]?\d\d[a-ekm]?)/i
                  ],
                  [
                    n,
                    [
                      q,
                      M
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i
                  ],
                  [
                    n,
                    [
                      q,
                      H
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(?:huawei|honor)([-\w ]+)[;\)]/i,
                    /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i
                  ],
                  [
                    n,
                    [
                      q,
                      H
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(poco[\w ]+)(?: bui|\))/i,
                    /\b; (\w+) build\/hm\1/i,
                    /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                    /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                    /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i
                  ],
                  [
                    [
                      n,
                      /_/g,
                      " "
                    ],
                    [
                      q,
                      O
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i
                  ],
                  [
                    [
                      n,
                      /_/g,
                      " "
                    ],
                    [
                      q,
                      O
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /; (\w+) bui.+ oppo/i,
                    /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "OPPO"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /vivo (\w+)(?: bui|\))/i,
                    /\b(v[12]\d{3}\w?[at])(?: bui|;)/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Vivo"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(rmx[12]\d{3})(?: bui|;|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Realme"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                    /\bmot(?:orola)?[- ](\w*)/i,
                    /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i
                  ],
                  [
                    n,
                    [
                      q,
                      J
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(mz60\d|xoom[2 ]{0,2}) build\//i
                  ],
                  [
                    n,
                    [
                      q,
                      J
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i
                  ],
                  [
                    n,
                    [
                      q,
                      "LG"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                    /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
                    /\blg-?([\d\w]+) bui/i
                  ],
                  [
                    n,
                    [
                      q,
                      "LG"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(ideatab[-\w ]+)/i,
                    /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Lenovo"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(?:maemo|nokia).*(n900|lumia \d+)/i,
                    /nokia[-_ ]?([-\w\.]*)/i
                  ],
                  [
                    [
                      n,
                      /_/g,
                      " "
                    ],
                    [
                      q,
                      "Nokia"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(pixel c)\b/i
                  ],
                  [
                    n,
                    [
                      q,
                      G
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      G
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i
                  ],
                  [
                    n,
                    [
                      q,
                      N
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /sony tablet [ps]/i,
                    /\b(?:sony)?sgp\w+(?: bui|\))/i
                  ],
                  [
                    [
                      n,
                      "Xperia Tablet"
                    ],
                    [
                      q,
                      N
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    / (kb2005|in20[12]5|be20[12][59])\b/i,
                    /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      "OnePlus"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(alexa)webm/i,
                    /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i,
                    /(kf[a-z]+)( bui|\)).+silk\//i
                  ],
                  [
                    n,
                    [
                      q,
                      z
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i
                  ],
                  [
                    [
                      n,
                      /(.+)/g,
                      "Fire Phone $1"
                    ],
                    [
                      q,
                      z
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(playbook);[-\w\),; ]+(rim)/i
                  ],
                  [
                    n,
                    q,
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b((?:bb[a-f]|st[hv])100-\d)/i,
                    /\(bb10; (\w+)/i
                  ],
                  [
                    n,
                    [
                      q,
                      C
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i
                  ],
                  [
                    n,
                    [
                      q,
                      B
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    / (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i
                  ],
                  [
                    n,
                    [
                      q,
                      B
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(nexus 9)/i
                  ],
                  [
                    n,
                    [
                      q,
                      "HTC"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                    /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                    /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i
                  ],
                  [
                    q,
                    [
                      n,
                      /_/g,
                      " "
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /droid.+; ([ab][1-7]-?[0178a]\d\d?)/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Acer"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /droid.+; (m[1-5] note) bui/i,
                    /\bmz-([-\w]{2,})/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Meizu"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,
                    /(hp) ([\w ]+\w)/i,
                    /(asus)-?(\w+)/i,
                    /(microsoft); (lumia[\w ]+)/i,
                    /(lenovo)[-_ ]?([-\w]+)/i,
                    /(jolla)/i,
                    /(oppo) ?([\w ]+) bui/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(kobo)\s(ereader|touch)/i,
                    /(archos) (gamepad2?)/i,
                    /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                    /(kindle)\/([\w\.]+)/i,
                    /(nook)[\w ]+build\/(\w+)/i,
                    /(dell) (strea[kpr\d ]*[\dko])/i,
                    /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                    /(trinity)[- ]*(t\d{3}) bui/i,
                    /(gigaset)[- ]+(q\w{1,9}) bui/i,
                    /(vodafone) ([\w ]+)(?:\)| bui)/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(surface duo)/i
                  ],
                  [
                    n,
                    [
                      q,
                      I
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /droid [\d\.]+; (fp\du?)(?: b|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Fairphone"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(u304aa)/i
                  ],
                  [
                    n,
                    [
                      q,
                      "AT&T"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\bsie-(\w*)/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Siemens"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(rct\w+) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "RCA"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(venue[\d ]{2,7}) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Dell"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(q(?:mv|ta)\w+) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Verizon"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Barnes & Noble"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(tm\d{3}\w+) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "NuVision"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(k88) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "ZTE"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(nx\d{3}j) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "ZTE"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(gen\d{3}) b.+49h/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Swiss"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(zur\d{3}) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Swiss"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b((zeki)?tb.*\b) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Zeki"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b([yr]\d{2}) b/i,
                    /\b(dragon[- ]+touch |dt)(\w{5}) b/i
                  ],
                  [
                    [
                      q,
                      "Dragon Touch"
                    ],
                    n,
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(ns-?\w{0,9}) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Insignia"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b((nxa|next)-?\w{0,9}) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "NextBook"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i
                  ],
                  [
                    [
                      q,
                      "Voice"
                    ],
                    n,
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(lvtel\-)?(v1[12]) b/i
                  ],
                  [
                    [
                      q,
                      "LvTel"
                    ],
                    n,
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(ph-1) /i
                  ],
                  [
                    n,
                    [
                      q,
                      "Essential"
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /\b(v(100md|700na|7011|917g).*\b) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Envizen"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b(trio[-\w\. ]+) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "MachSpeed"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\btu_(1491) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Rotor"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(shield[\w ]+) b/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Nvidia"
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(sprint) (\w+)/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(kin\.[onetw]{3})/i
                  ],
                  [
                    [
                      n,
                      /\./g,
                      " "
                    ],
                    [
                      q,
                      I
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i
                  ],
                  [
                    n,
                    [
                      q,
                      P
                    ],
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i
                  ],
                  [
                    n,
                    [
                      q,
                      P
                    ],
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /smart-tv.+(samsung)/i
                  ],
                  [
                    q,
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /hbbtv.+maple;(\d+)/i
                  ],
                  [
                    [
                      n,
                      /^/,
                      "SmartTV"
                    ],
                    [
                      q,
                      L
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i
                  ],
                  [
                    [
                      q,
                      "LG"
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /(apple) ?tv/i
                  ],
                  [
                    q,
                    [
                      n,
                      A + " TV"
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /crkey/i
                  ],
                  [
                    [
                      n,
                      E + "cast"
                    ],
                    [
                      q,
                      G
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /droid.+aft(\w)( bui|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      z
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /\(dtv[\);].+(aquos)/i,
                    /(aquos-tv[\w ]+)\)/i
                  ],
                  [
                    n,
                    [
                      q,
                      M
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /(bravia[\w ]+)( bui|\))/i
                  ],
                  [
                    n,
                    [
                      q,
                      N
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /(mitv-\w{5}) bui/i
                  ],
                  [
                    n,
                    [
                      q,
                      O
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /Hbbtv.*(technisat) (.*);/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                    /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i
                  ],
                  [
                    [
                      q,
                      X
                    ],
                    [
                      n,
                      X
                    ],
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i
                  ],
                  [
                    [
                      p,
                      w
                    ]
                  ],
                  [
                    /(ouya)/i,
                    /(nintendo) ([wids3utch]+)/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      t
                    ]
                  ],
                  [
                    /droid.+; (shield) bui/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Nvidia"
                    ],
                    [
                      p,
                      t
                    ]
                  ],
                  [
                    /(playstation [345portablevi]+)/i
                  ],
                  [
                    n,
                    [
                      q,
                      N
                    ],
                    [
                      p,
                      t
                    ]
                  ],
                  [
                    /\b(xbox(?: one)?(?!; xbox))[\); ]/i
                  ],
                  [
                    n,
                    [
                      q,
                      I
                    ],
                    [
                      p,
                      t
                    ]
                  ],
                  [
                    /((pebble))app/i
                  ],
                  [
                    q,
                    n,
                    [
                      p,
                      x
                    ]
                  ],
                  [
                    /(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i
                  ],
                  [
                    n,
                    [
                      q,
                      A
                    ],
                    [
                      p,
                      x
                    ]
                  ],
                  [
                    /droid.+; (glass) \d/i
                  ],
                  [
                    n,
                    [
                      q,
                      G
                    ],
                    [
                      p,
                      x
                    ]
                  ],
                  [
                    /droid.+; (wt63?0{2,3})\)/i
                  ],
                  [
                    n,
                    [
                      q,
                      P
                    ],
                    [
                      p,
                      x
                    ]
                  ],
                  [
                    /(quest( 2| pro)?)/i
                  ],
                  [
                    n,
                    [
                      q,
                      Q
                    ],
                    [
                      p,
                      x
                    ]
                  ],
                  [
                    /(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i
                  ],
                  [
                    q,
                    [
                      p,
                      y
                    ]
                  ],
                  [
                    /(aeobc)\b/i
                  ],
                  [
                    n,
                    [
                      q,
                      z
                    ],
                    [
                      p,
                      y
                    ]
                  ],
                  [
                    /droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i
                  ],
                  [
                    n,
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i
                  ],
                  [
                    n,
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i
                  ],
                  [
                    [
                      p,
                      v
                    ]
                  ],
                  [
                    /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i
                  ],
                  [
                    [
                      p,
                      u
                    ]
                  ],
                  [
                    /(android[-\w\. ]{0,9});.+buil/i
                  ],
                  [
                    n,
                    [
                      q,
                      "Generic"
                    ]
                  ]
                ],
                engine: [
                  [
                    /windows.+ edge\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "EdgeHTML"
                    ]
                  ],
                  [
                    /webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Blink"
                    ]
                  ],
                  [
                    /(presto)\/([\w\.]+)/i,
                    /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,
                    /ekioh(flow)\/([\w\.]+)/i,
                    /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                    /(icab)[\/ ]([23]\.[\d\.]+)/i,
                    /\b(libweb)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /rv\:([\w\.]{1,9})\b.+(gecko)/i
                  ],
                  [
                    r,
                    o
                  ]
                ],
                os: [
                  [
                    /microsoft (windows) (vista|xp)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(windows) nt 6\.2; (arm)/i,
                    /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,
                    /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i
                  ],
                  [
                    o,
                    [
                      r,
                      Z,
                      $
                    ]
                  ],
                  [
                    /(win(?=3|9|n)|win 9x )([nt\d\.]+)/i
                  ],
                  [
                    [
                      o,
                      "Windows"
                    ],
                    [
                      r,
                      Z,
                      $
                    ]
                  ],
                  [
                    /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,
                    /ios;fbsv\/([\d\.]+)/i,
                    /cfnetwork\/.+darwin/i
                  ],
                  [
                    [
                      r,
                      /_/g,
                      "."
                    ],
                    [
                      o,
                      "iOS"
                    ]
                  ],
                  [
                    /(mac os x) ?([\w\. ]*)/i,
                    /(macintosh|mac_powerpc\b)(?!.+haiku)/i
                  ],
                  [
                    [
                      o,
                      S
                    ],
                    [
                      r,
                      /_/g,
                      "."
                    ]
                  ],
                  [
                    /droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i
                  ],
                  [
                    r,
                    o
                  ],
                  [
                    /(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
                    /(blackberry)\w*\/([\w\.]*)/i,
                    /(tizen|kaios)[\/ ]([\w\.]+)/i,
                    /\((series40);/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /\(bb(10);/i
                  ],
                  [
                    r,
                    [
                      o,
                      C
                    ]
                  ],
                  [
                    /(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "Symbian"
                    ]
                  ],
                  [
                    /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      F + " OS"
                    ]
                  ],
                  [
                    /web0s;.+rt(tv)/i,
                    /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "webOS"
                    ]
                  ],
                  [
                    /watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      "watchOS"
                    ]
                  ],
                  [
                    /crkey\/([\d\.]+)/i
                  ],
                  [
                    r,
                    [
                      o,
                      E + "cast"
                    ]
                  ],
                  [
                    /(cros) [\w]+(?:\)| ([\w\.]+)\b)/i
                  ],
                  [
                    [
                      o,
                      R
                    ],
                    r
                  ],
                  [
                    /panasonic;(viera)/i,
                    /(netrange)mmh/i,
                    /(nettv)\/(\d+\.[\w\.]+)/i,
                    /(nintendo|playstation) ([wids345portablevuch]+)/i,
                    /(xbox); +xbox ([^\);]+)/i,
                    /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                    /(mint)[\/\(\) ]?(\w*)/i,
                    /(mageia|vectorlinux)[; ]/i,
                    /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                    /(hurd|linux) ?([\w\.]*)/i,
                    /(gnu) ?([\w\.]*)/i,
                    /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                    /(haiku) (\w+)/i
                  ],
                  [
                    o,
                    r
                  ],
                  [
                    /(sunos) ?([\w\.\d]*)/i
                  ],
                  [
                    [
                      o,
                      "Solaris"
                    ],
                    r
                  ],
                  [
                    /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,
                    /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                    /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,
                    /(unix) ?([\w\.]*)/i
                  ],
                  [
                    o,
                    r
                  ]
                ]
              }, aa = function(a2, b2) {
                if (typeof a2 === k && (b2 = a2, a2 = h), !(this instanceof aa)) return new aa(a2, b2).getResult();
                var c2 = typeof g2 !== j && g2.navigator ? g2.navigator : h, d2 = a2 || (c2 && c2.userAgent ? c2.userAgent : ""), e3 = c2 && c2.userAgentData ? c2.userAgentData : h, f3 = b2 ? T(_, b2) : _, t2 = c2 && c2.userAgent == d2;
                return this.getBrowser = function() {
                  var a3, b3 = {};
                  return b3[o] = h, b3[r] = h, Y.call(b3, d2, f3.browser), b3[m] = typeof (a3 = b3[r]) === l ? a3.replace(/[^\d\.]/g, "").split(".")[0] : h, t2 && c2 && c2.brave && typeof c2.brave.isBrave == i && (b3[o] = "Brave"), b3;
                }, this.getCPU = function() {
                  var a3 = {};
                  return a3[s] = h, Y.call(a3, d2, f3.cpu), a3;
                }, this.getDevice = function() {
                  var a3 = {};
                  return a3[q] = h, a3[n] = h, a3[p] = h, Y.call(a3, d2, f3.device), t2 && !a3[p] && e3 && e3.mobile && (a3[p] = u), t2 && "Macintosh" == a3[n] && c2 && typeof c2.standalone !== j && c2.maxTouchPoints && c2.maxTouchPoints > 2 && (a3[n] = "iPad", a3[p] = v), a3;
                }, this.getEngine = function() {
                  var a3 = {};
                  return a3[o] = h, a3[r] = h, Y.call(a3, d2, f3.engine), a3;
                }, this.getOS = function() {
                  var a3 = {};
                  return a3[o] = h, a3[r] = h, Y.call(a3, d2, f3.os), t2 && !a3[o] && e3 && "Unknown" != e3.platform && (a3[o] = e3.platform.replace(/chrome os/i, R).replace(/macos/i, S)), a3;
                }, this.getResult = function() {
                  return {
                    ua: this.getUA(),
                    browser: this.getBrowser(),
                    engine: this.getEngine(),
                    os: this.getOS(),
                    device: this.getDevice(),
                    cpu: this.getCPU()
                  };
                }, this.getUA = function() {
                  return d2;
                }, this.setUA = function(a3) {
                  return d2 = typeof a3 === l && a3.length > 350 ? X(a3, 350) : a3, this;
                }, this.setUA(d2), this;
              };
              aa.VERSION = "1.0.35", aa.BROWSER = U([
                o,
                r,
                m
              ]), aa.CPU = U([
                s
              ]), aa.DEVICE = U([
                n,
                q,
                p,
                t,
                u,
                w,
                v,
                x,
                y
              ]), aa.ENGINE = aa.OS = U([
                o,
                r
              ]), typeof f2 !== j ? (e2.exports && (f2 = e2.exports = aa), f2.UAParser = aa) : c.amdO ? void 0 === (d = function() {
                return aa;
              }.call(b, c, b, a)) || (a.exports = d) : typeof g2 !== j && (g2.UAParser = aa);
              var ab = typeof g2 !== j && (g2.jQuery || g2.Zepto);
              if (ab && !ab.ua) {
                var ac = new aa();
                ab.ua = ac.getResult(), ab.ua.get = function() {
                  return ac.getUA();
                }, ab.ua.set = function(a2) {
                  ac.setUA(a2);
                  var b2 = ac.getResult();
                  for (var c2 in b2) ab.ua[c2] = b2[c2];
                };
              }
            }("object" == typeof window ? window : this);
          }
        }, f = {};
        function g(a2) {
          var b2 = f[a2];
          if (void 0 !== b2) return b2.exports;
          var c2 = f[a2] = {
            exports: {}
          }, d2 = true;
          try {
            e[a2].call(c2.exports, c2, c2.exports, g), d2 = false;
          } finally {
            d2 && delete f[a2];
          }
          return c2.exports;
        }
        g.ab = "//", a.exports = g(226);
      })();
    },
    521: (a) => {
      "use strict";
      a.exports = __require("node:async_hooks");
    },
    571: (a, b, c) => {
      "use strict";
      let d;
      c.r(b), c.d(b, {
        default: () => by
      });
      var e, f = {};
      async function g() {
        return "_ENTRIES" in globalThis && _ENTRIES.middleware_instrumentation && await _ENTRIES.middleware_instrumentation;
      }
      c.r(f), c.d(f, {
        config: () => bu,
        middleware: () => bt
      });
      let h = null;
      async function i() {
        if ("phase-production-build" === process.env.NEXT_PHASE) return;
        h || (h = g());
        let a10 = await h;
        if (null == a10 ? void 0 : a10.register) try {
          await a10.register();
        } catch (a11) {
          throw a11.message = `An error occurred while loading instrumentation hook: ${a11.message}`, a11;
        }
      }
      async function j(...a10) {
        let b2 = await g();
        try {
          var c2;
          await (null == b2 || null == (c2 = b2.onRequestError) ? void 0 : c2.call(b2, ...a10));
        } catch (a11) {
          console.error("Error in instrumentation.onRequestError:", a11);
        }
      }
      let k = null;
      function l() {
        return k || (k = i()), k;
      }
      function m(a10) {
        return `The edge runtime does not support Node.js '${a10}' module.
Learn More: https://nextjs.org/docs/messages/node-module-in-edge-runtime`;
      }
      process !== c.g.process && (process.env = c.g.process.env, c.g.process = process);
      try {
        Object.defineProperty(globalThis, "__import_unsupported", {
          value: function(a10) {
            let b2 = new Proxy(function() {
            }, {
              get(b3, c2) {
                if ("then" === c2) return {};
                throw Object.defineProperty(Error(m(a10)), "__NEXT_ERROR_CODE", {
                  value: "E394",
                  enumerable: false,
                  configurable: true
                });
              },
              construct() {
                throw Object.defineProperty(Error(m(a10)), "__NEXT_ERROR_CODE", {
                  value: "E394",
                  enumerable: false,
                  configurable: true
                });
              },
              apply(c2, d2, e2) {
                if ("function" == typeof e2[0]) return e2[0](b2);
                throw Object.defineProperty(Error(m(a10)), "__NEXT_ERROR_CODE", {
                  value: "E394",
                  enumerable: false,
                  configurable: true
                });
              }
            });
            return new Proxy({}, {
              get: () => b2
            });
          },
          enumerable: false,
          configurable: false
        });
      } catch {
      }
      l();
      class n extends Error {
        constructor({ page: a10 }) {
          super(`The middleware "${a10}" accepts an async API directly with the form:
  
  export function middleware(request, event) {
    return NextResponse.redirect('/new-location')
  }
  
  Read more: https://nextjs.org/docs/messages/middleware-new-signature
  `);
        }
      }
      class o extends Error {
        constructor() {
          super(`The request.page has been deprecated in favour of \`URLPattern\`.
  Read more: https://nextjs.org/docs/messages/middleware-request-page
  `);
        }
      }
      class p extends Error {
        constructor() {
          super(`The request.ua has been removed in favour of \`userAgent\` function.
  Read more: https://nextjs.org/docs/messages/middleware-parse-user-agent
  `);
        }
      }
      let q = "_N_T_", r = {
        shared: "shared",
        reactServerComponents: "rsc",
        serverSideRendering: "ssr",
        actionBrowser: "action-browser",
        apiNode: "api-node",
        apiEdge: "api-edge",
        middleware: "middleware",
        instrument: "instrument",
        edgeAsset: "edge-asset",
        appPagesBrowser: "app-pages-browser",
        pagesDirBrowser: "pages-dir-browser",
        pagesDirEdge: "pages-dir-edge",
        pagesDirNode: "pages-dir-node"
      };
      function s(a10) {
        var b2, c2, d2, e2, f2, g2 = [], h2 = 0;
        function i2() {
          for (; h2 < a10.length && /\s/.test(a10.charAt(h2)); ) h2 += 1;
          return h2 < a10.length;
        }
        for (; h2 < a10.length; ) {
          for (b2 = h2, f2 = false; i2(); ) if ("," === (c2 = a10.charAt(h2))) {
            for (d2 = h2, h2 += 1, i2(), e2 = h2; h2 < a10.length && "=" !== (c2 = a10.charAt(h2)) && ";" !== c2 && "," !== c2; ) h2 += 1;
            h2 < a10.length && "=" === a10.charAt(h2) ? (f2 = true, h2 = e2, g2.push(a10.substring(b2, d2)), b2 = h2) : h2 = d2 + 1;
          } else h2 += 1;
          (!f2 || h2 >= a10.length) && g2.push(a10.substring(b2, a10.length));
        }
        return g2;
      }
      function t(a10) {
        let b2 = {}, c2 = [];
        if (a10) for (let [d2, e2] of a10.entries()) "set-cookie" === d2.toLowerCase() ? (c2.push(...s(e2)), b2[d2] = 1 === c2.length ? c2[0] : c2) : b2[d2] = e2;
        return b2;
      }
      function u(a10) {
        try {
          return String(new URL(String(a10)));
        } catch (b2) {
          throw Object.defineProperty(Error(`URL is malformed "${String(a10)}". Please use only absolute URLs - https://nextjs.org/docs/messages/middleware-relative-urls`, {
            cause: b2
          }), "__NEXT_ERROR_CODE", {
            value: "E61",
            enumerable: false,
            configurable: true
          });
        }
      }
      ({
        ...r,
        GROUP: {
          builtinReact: [
            r.reactServerComponents,
            r.actionBrowser
          ],
          serverOnly: [
            r.reactServerComponents,
            r.actionBrowser,
            r.instrument,
            r.middleware
          ],
          neutralTarget: [
            r.apiNode,
            r.apiEdge
          ],
          clientOnly: [
            r.serverSideRendering,
            r.appPagesBrowser
          ],
          bundled: [
            r.reactServerComponents,
            r.actionBrowser,
            r.serverSideRendering,
            r.appPagesBrowser,
            r.shared,
            r.instrument,
            r.middleware
          ],
          appPages: [
            r.reactServerComponents,
            r.serverSideRendering,
            r.appPagesBrowser,
            r.actionBrowser
          ]
        }
      });
      let v = Symbol("response"), w = Symbol("passThrough"), x = Symbol("waitUntil");
      class y {
        constructor(a10, b2) {
          this[w] = false, this[x] = b2 ? {
            kind: "external",
            function: b2
          } : {
            kind: "internal",
            promises: []
          };
        }
        respondWith(a10) {
          this[v] || (this[v] = Promise.resolve(a10));
        }
        passThroughOnException() {
          this[w] = true;
        }
        waitUntil(a10) {
          if ("external" === this[x].kind) return (0, this[x].function)(a10);
          this[x].promises.push(a10);
        }
      }
      class z extends y {
        constructor(a10) {
          var b2;
          super(a10.request, null == (b2 = a10.context) ? void 0 : b2.waitUntil), this.sourcePage = a10.page;
        }
        get request() {
          throw Object.defineProperty(new n({
            page: this.sourcePage
          }), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
          });
        }
        respondWith() {
          throw Object.defineProperty(new n({
            page: this.sourcePage
          }), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
          });
        }
      }
      function A(a10) {
        return a10.replace(/\/$/, "") || "/";
      }
      function B(a10) {
        let b2 = a10.indexOf("#"), c2 = a10.indexOf("?"), d2 = c2 > -1 && (b2 < 0 || c2 < b2);
        return d2 || b2 > -1 ? {
          pathname: a10.substring(0, d2 ? c2 : b2),
          query: d2 ? a10.substring(c2, b2 > -1 ? b2 : void 0) : "",
          hash: b2 > -1 ? a10.slice(b2) : ""
        } : {
          pathname: a10,
          query: "",
          hash: ""
        };
      }
      function C(a10, b2) {
        if (!a10.startsWith("/") || !b2) return a10;
        let { pathname: c2, query: d2, hash: e2 } = B(a10);
        return "" + b2 + c2 + d2 + e2;
      }
      function D(a10, b2) {
        if (!a10.startsWith("/") || !b2) return a10;
        let { pathname: c2, query: d2, hash: e2 } = B(a10);
        return "" + c2 + b2 + d2 + e2;
      }
      function E(a10, b2) {
        if ("string" != typeof a10) return false;
        let { pathname: c2 } = B(a10);
        return c2 === b2 || c2.startsWith(b2 + "/");
      }
      let F = /* @__PURE__ */ new WeakMap();
      function G(a10, b2) {
        let c2;
        if (!b2) return {
          pathname: a10
        };
        let d2 = F.get(b2);
        d2 || (d2 = b2.map((a11) => a11.toLowerCase()), F.set(b2, d2));
        let e2 = a10.split("/", 2);
        if (!e2[1]) return {
          pathname: a10
        };
        let f2 = e2[1].toLowerCase(), g2 = d2.indexOf(f2);
        return g2 < 0 ? {
          pathname: a10
        } : (c2 = b2[g2], {
          pathname: a10 = a10.slice(c2.length + 1) || "/",
          detectedLocale: c2
        });
      }
      let H = /(?!^https?:\/\/)(127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}|\[::1\]|localhost)/;
      function I(a10, b2) {
        return new URL(String(a10).replace(H, "localhost"), b2 && String(b2).replace(H, "localhost"));
      }
      let J = Symbol("NextURLInternal");
      class K {
        constructor(a10, b2, c2) {
          let d2, e2;
          "object" == typeof b2 && "pathname" in b2 || "string" == typeof b2 ? (d2 = b2, e2 = c2 || {}) : e2 = c2 || b2 || {}, this[J] = {
            url: I(a10, d2 ?? e2.base),
            options: e2,
            basePath: ""
          }, this.analyze();
        }
        analyze() {
          var a10, b2, c2, d2, e2;
          let f2 = function(a11, b3) {
            var c3, d3;
            let { basePath: e3, i18n: f3, trailingSlash: g3 } = null != (c3 = b3.nextConfig) ? c3 : {}, h3 = {
              pathname: a11,
              trailingSlash: "/" !== a11 ? a11.endsWith("/") : g3
            };
            e3 && E(h3.pathname, e3) && (h3.pathname = function(a12, b4) {
              if (!E(a12, b4)) return a12;
              let c4 = a12.slice(b4.length);
              return c4.startsWith("/") ? c4 : "/" + c4;
            }(h3.pathname, e3), h3.basePath = e3);
            let i2 = h3.pathname;
            if (h3.pathname.startsWith("/_next/data/") && h3.pathname.endsWith(".json")) {
              let a12 = h3.pathname.replace(/^\/_next\/data\//, "").replace(/\.json$/, "").split("/");
              h3.buildId = a12[0], i2 = "index" !== a12[1] ? "/" + a12.slice(1).join("/") : "/", true === b3.parseData && (h3.pathname = i2);
            }
            if (f3) {
              let a12 = b3.i18nProvider ? b3.i18nProvider.analyze(h3.pathname) : G(h3.pathname, f3.locales);
              h3.locale = a12.detectedLocale, h3.pathname = null != (d3 = a12.pathname) ? d3 : h3.pathname, !a12.detectedLocale && h3.buildId && (a12 = b3.i18nProvider ? b3.i18nProvider.analyze(i2) : G(i2, f3.locales)).detectedLocale && (h3.locale = a12.detectedLocale);
            }
            return h3;
          }(this[J].url.pathname, {
            nextConfig: this[J].options.nextConfig,
            parseData: true,
            i18nProvider: this[J].options.i18nProvider
          }), g2 = function(a11, b3) {
            let c3;
            if ((null == b3 ? void 0 : b3.host) && !Array.isArray(b3.host)) c3 = b3.host.toString().split(":", 1)[0];
            else {
              if (!a11.hostname) return;
              c3 = a11.hostname;
            }
            return c3.toLowerCase();
          }(this[J].url, this[J].options.headers);
          this[J].domainLocale = this[J].options.i18nProvider ? this[J].options.i18nProvider.detectDomainLocale(g2) : function(a11, b3, c3) {
            if (a11) for (let f3 of (c3 && (c3 = c3.toLowerCase()), a11)) {
              var d3, e3;
              if (b3 === (null == (d3 = f3.domain) ? void 0 : d3.split(":", 1)[0].toLowerCase()) || c3 === f3.defaultLocale.toLowerCase() || (null == (e3 = f3.locales) ? void 0 : e3.some((a12) => a12.toLowerCase() === c3))) return f3;
            }
          }(null == (b2 = this[J].options.nextConfig) || null == (a10 = b2.i18n) ? void 0 : a10.domains, g2);
          let h2 = (null == (c2 = this[J].domainLocale) ? void 0 : c2.defaultLocale) || (null == (e2 = this[J].options.nextConfig) || null == (d2 = e2.i18n) ? void 0 : d2.defaultLocale);
          this[J].url.pathname = f2.pathname, this[J].defaultLocale = h2, this[J].basePath = f2.basePath ?? "", this[J].buildId = f2.buildId, this[J].locale = f2.locale ?? h2, this[J].trailingSlash = f2.trailingSlash;
        }
        formatPathname() {
          var a10;
          let b2;
          return b2 = function(a11, b3, c2, d2) {
            if (!b3 || b3 === c2) return a11;
            let e2 = a11.toLowerCase();
            return !d2 && (E(e2, "/api") || E(e2, "/" + b3.toLowerCase())) ? a11 : C(a11, "/" + b3);
          }((a10 = {
            basePath: this[J].basePath,
            buildId: this[J].buildId,
            defaultLocale: this[J].options.forceLocale ? void 0 : this[J].defaultLocale,
            locale: this[J].locale,
            pathname: this[J].url.pathname,
            trailingSlash: this[J].trailingSlash
          }).pathname, a10.locale, a10.buildId ? void 0 : a10.defaultLocale, a10.ignorePrefix), (a10.buildId || !a10.trailingSlash) && (b2 = A(b2)), a10.buildId && (b2 = D(C(b2, "/_next/data/" + a10.buildId), "/" === a10.pathname ? "index.json" : ".json")), b2 = C(b2, a10.basePath), !a10.buildId && a10.trailingSlash ? b2.endsWith("/") ? b2 : D(b2, "/") : A(b2);
        }
        formatSearch() {
          return this[J].url.search;
        }
        get buildId() {
          return this[J].buildId;
        }
        set buildId(a10) {
          this[J].buildId = a10;
        }
        get locale() {
          return this[J].locale ?? "";
        }
        set locale(a10) {
          var b2, c2;
          if (!this[J].locale || !(null == (c2 = this[J].options.nextConfig) || null == (b2 = c2.i18n) ? void 0 : b2.locales.includes(a10))) throw Object.defineProperty(TypeError(`The NextURL configuration includes no locale "${a10}"`), "__NEXT_ERROR_CODE", {
            value: "E597",
            enumerable: false,
            configurable: true
          });
          this[J].locale = a10;
        }
        get defaultLocale() {
          return this[J].defaultLocale;
        }
        get domainLocale() {
          return this[J].domainLocale;
        }
        get searchParams() {
          return this[J].url.searchParams;
        }
        get host() {
          return this[J].url.host;
        }
        set host(a10) {
          this[J].url.host = a10;
        }
        get hostname() {
          return this[J].url.hostname;
        }
        set hostname(a10) {
          this[J].url.hostname = a10;
        }
        get port() {
          return this[J].url.port;
        }
        set port(a10) {
          this[J].url.port = a10;
        }
        get protocol() {
          return this[J].url.protocol;
        }
        set protocol(a10) {
          this[J].url.protocol = a10;
        }
        get href() {
          let a10 = this.formatPathname(), b2 = this.formatSearch();
          return `${this.protocol}//${this.host}${a10}${b2}${this.hash}`;
        }
        set href(a10) {
          this[J].url = I(a10), this.analyze();
        }
        get origin() {
          return this[J].url.origin;
        }
        get pathname() {
          return this[J].url.pathname;
        }
        set pathname(a10) {
          this[J].url.pathname = a10;
        }
        get hash() {
          return this[J].url.hash;
        }
        set hash(a10) {
          this[J].url.hash = a10;
        }
        get search() {
          return this[J].url.search;
        }
        set search(a10) {
          this[J].url.search = a10;
        }
        get password() {
          return this[J].url.password;
        }
        set password(a10) {
          this[J].url.password = a10;
        }
        get username() {
          return this[J].url.username;
        }
        set username(a10) {
          this[J].url.username = a10;
        }
        get basePath() {
          return this[J].basePath;
        }
        set basePath(a10) {
          this[J].basePath = a10.startsWith("/") ? a10 : `/${a10}`;
        }
        toString() {
          return this.href;
        }
        toJSON() {
          return this.href;
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            href: this.href,
            origin: this.origin,
            protocol: this.protocol,
            username: this.username,
            password: this.password,
            host: this.host,
            hostname: this.hostname,
            port: this.port,
            pathname: this.pathname,
            search: this.search,
            searchParams: this.searchParams,
            hash: this.hash
          };
        }
        clone() {
          return new K(String(this), this[J].options);
        }
      }
      var L = c(443);
      let M = Symbol("internal request");
      class N extends Request {
        constructor(a10, b2 = {}) {
          let c2 = "string" != typeof a10 && "url" in a10 ? a10.url : String(a10);
          u(c2), a10 instanceof Request ? super(a10, b2) : super(c2, b2);
          let d2 = new K(c2, {
            headers: t(this.headers),
            nextConfig: b2.nextConfig
          });
          this[M] = {
            cookies: new L.RequestCookies(this.headers),
            nextUrl: d2,
            url: d2.toString()
          };
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            cookies: this.cookies,
            nextUrl: this.nextUrl,
            url: this.url,
            bodyUsed: this.bodyUsed,
            cache: this.cache,
            credentials: this.credentials,
            destination: this.destination,
            headers: Object.fromEntries(this.headers),
            integrity: this.integrity,
            keepalive: this.keepalive,
            method: this.method,
            mode: this.mode,
            redirect: this.redirect,
            referrer: this.referrer,
            referrerPolicy: this.referrerPolicy,
            signal: this.signal
          };
        }
        get cookies() {
          return this[M].cookies;
        }
        get nextUrl() {
          return this[M].nextUrl;
        }
        get page() {
          throw new o();
        }
        get ua() {
          throw new p();
        }
        get url() {
          return this[M].url;
        }
      }
      class O {
        static get(a10, b2, c2) {
          let d2 = Reflect.get(a10, b2, c2);
          return "function" == typeof d2 ? d2.bind(a10) : d2;
        }
        static set(a10, b2, c2, d2) {
          return Reflect.set(a10, b2, c2, d2);
        }
        static has(a10, b2) {
          return Reflect.has(a10, b2);
        }
        static deleteProperty(a10, b2) {
          return Reflect.deleteProperty(a10, b2);
        }
      }
      let P = Symbol("internal response"), Q = /* @__PURE__ */ new Set([
        301,
        302,
        303,
        307,
        308
      ]);
      function R(a10, b2) {
        var c2;
        if (null == a10 || null == (c2 = a10.request) ? void 0 : c2.headers) {
          if (!(a10.request.headers instanceof Headers)) throw Object.defineProperty(Error("request.headers must be an instance of Headers"), "__NEXT_ERROR_CODE", {
            value: "E119",
            enumerable: false,
            configurable: true
          });
          let c3 = [];
          for (let [d2, e2] of a10.request.headers) b2.set("x-middleware-request-" + d2, e2), c3.push(d2);
          b2.set("x-middleware-override-headers", c3.join(","));
        }
      }
      class S extends Response {
        constructor(a10, b2 = {}) {
          super(a10, b2);
          let c2 = this.headers, d2 = new Proxy(new L.ResponseCookies(c2), {
            get(a11, d3, e2) {
              switch (d3) {
                case "delete":
                case "set":
                  return (...e3) => {
                    let f2 = Reflect.apply(a11[d3], a11, e3), g2 = new Headers(c2);
                    return f2 instanceof L.ResponseCookies && c2.set("x-middleware-set-cookie", f2.getAll().map((a12) => (0, L.stringifyCookie)(a12)).join(",")), R(b2, g2), f2;
                  };
                default:
                  return O.get(a11, d3, e2);
              }
            }
          });
          this[P] = {
            cookies: d2,
            url: b2.url ? new K(b2.url, {
              headers: t(c2),
              nextConfig: b2.nextConfig
            }) : void 0
          };
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            cookies: this.cookies,
            url: this.url,
            body: this.body,
            bodyUsed: this.bodyUsed,
            headers: Object.fromEntries(this.headers),
            ok: this.ok,
            redirected: this.redirected,
            status: this.status,
            statusText: this.statusText,
            type: this.type
          };
        }
        get cookies() {
          return this[P].cookies;
        }
        static json(a10, b2) {
          let c2 = Response.json(a10, b2);
          return new S(c2.body, c2);
        }
        static redirect(a10, b2) {
          let c2 = "number" == typeof b2 ? b2 : (null == b2 ? void 0 : b2.status) ?? 307;
          if (!Q.has(c2)) throw Object.defineProperty(RangeError('Failed to execute "redirect" on "response": Invalid status code'), "__NEXT_ERROR_CODE", {
            value: "E529",
            enumerable: false,
            configurable: true
          });
          let d2 = "object" == typeof b2 ? b2 : {}, e2 = new Headers(null == d2 ? void 0 : d2.headers);
          return e2.set("Location", u(a10)), new S(null, {
            ...d2,
            headers: e2,
            status: c2
          });
        }
        static rewrite(a10, b2) {
          let c2 = new Headers(null == b2 ? void 0 : b2.headers);
          return c2.set("x-middleware-rewrite", u(a10)), R(b2, c2), new S(null, {
            ...b2,
            headers: c2
          });
        }
        static next(a10) {
          let b2 = new Headers(null == a10 ? void 0 : a10.headers);
          return b2.set("x-middleware-next", "1"), R(a10, b2), new S(null, {
            ...a10,
            headers: b2
          });
        }
      }
      function T(a10, b2) {
        let c2 = "string" == typeof b2 ? new URL(b2) : b2, d2 = new URL(a10, b2), e2 = d2.origin === c2.origin;
        return {
          url: e2 ? d2.toString().slice(c2.origin.length) : d2.toString(),
          isRelative: e2
        };
      }
      let U = "next-router-prefetch", V = [
        "rsc",
        "next-router-state-tree",
        U,
        "next-hmr-refresh",
        "next-router-segment-prefetch"
      ], W = "_rsc";
      class X extends Error {
        constructor() {
          super("Headers cannot be modified. Read more: https://nextjs.org/docs/app/api-reference/functions/headers");
        }
        static callable() {
          throw new X();
        }
      }
      class Y extends Headers {
        constructor(a10) {
          super(), this.headers = new Proxy(a10, {
            get(b2, c2, d2) {
              if ("symbol" == typeof c2) return O.get(b2, c2, d2);
              let e2 = c2.toLowerCase(), f2 = Object.keys(a10).find((a11) => a11.toLowerCase() === e2);
              if (void 0 !== f2) return O.get(b2, f2, d2);
            },
            set(b2, c2, d2, e2) {
              if ("symbol" == typeof c2) return O.set(b2, c2, d2, e2);
              let f2 = c2.toLowerCase(), g2 = Object.keys(a10).find((a11) => a11.toLowerCase() === f2);
              return O.set(b2, g2 ?? c2, d2, e2);
            },
            has(b2, c2) {
              if ("symbol" == typeof c2) return O.has(b2, c2);
              let d2 = c2.toLowerCase(), e2 = Object.keys(a10).find((a11) => a11.toLowerCase() === d2);
              return void 0 !== e2 && O.has(b2, e2);
            },
            deleteProperty(b2, c2) {
              if ("symbol" == typeof c2) return O.deleteProperty(b2, c2);
              let d2 = c2.toLowerCase(), e2 = Object.keys(a10).find((a11) => a11.toLowerCase() === d2);
              return void 0 === e2 || O.deleteProperty(b2, e2);
            }
          });
        }
        static seal(a10) {
          return new Proxy(a10, {
            get(a11, b2, c2) {
              switch (b2) {
                case "append":
                case "delete":
                case "set":
                  return X.callable;
                default:
                  return O.get(a11, b2, c2);
              }
            }
          });
        }
        merge(a10) {
          return Array.isArray(a10) ? a10.join(", ") : a10;
        }
        static from(a10) {
          return a10 instanceof Headers ? a10 : new Y(a10);
        }
        append(a10, b2) {
          let c2 = this.headers[a10];
          "string" == typeof c2 ? this.headers[a10] = [
            c2,
            b2
          ] : Array.isArray(c2) ? c2.push(b2) : this.headers[a10] = b2;
        }
        delete(a10) {
          delete this.headers[a10];
        }
        get(a10) {
          let b2 = this.headers[a10];
          return void 0 !== b2 ? this.merge(b2) : null;
        }
        has(a10) {
          return void 0 !== this.headers[a10];
        }
        set(a10, b2) {
          this.headers[a10] = b2;
        }
        forEach(a10, b2) {
          for (let [c2, d2] of this.entries()) a10.call(b2, d2, c2, this);
        }
        *entries() {
          for (let a10 of Object.keys(this.headers)) {
            let b2 = a10.toLowerCase(), c2 = this.get(b2);
            yield [
              b2,
              c2
            ];
          }
        }
        *keys() {
          for (let a10 of Object.keys(this.headers)) {
            let b2 = a10.toLowerCase();
            yield b2;
          }
        }
        *values() {
          for (let a10 of Object.keys(this.headers)) {
            let b2 = this.get(a10);
            yield b2;
          }
        }
        [Symbol.iterator]() {
          return this.entries();
        }
      }
      let Z = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: false,
        configurable: true
      });
      class $ {
        disable() {
          throw Z;
        }
        getStore() {
        }
        run() {
          throw Z;
        }
        exit() {
          throw Z;
        }
        enterWith() {
          throw Z;
        }
        static bind(a10) {
          return a10;
        }
      }
      let _ = "undefined" != typeof globalThis && globalThis.AsyncLocalStorage;
      function aa() {
        return _ ? new _() : new $();
      }
      let ab = aa();
      class ac extends Error {
        constructor() {
          super("Cookies can only be modified in a Server Action or Route Handler. Read more: https://nextjs.org/docs/app/api-reference/functions/cookies#options");
        }
        static callable() {
          throw new ac();
        }
      }
      class ad {
        static seal(a10) {
          return new Proxy(a10, {
            get(a11, b2, c2) {
              switch (b2) {
                case "clear":
                case "delete":
                case "set":
                  return ac.callable;
                default:
                  return O.get(a11, b2, c2);
              }
            }
          });
        }
      }
      let ae = Symbol.for("next.mutated.cookies");
      class af {
        static wrap(a10, b2) {
          let c2 = new L.ResponseCookies(new Headers());
          for (let b3 of a10.getAll()) c2.set(b3);
          let d2 = [], e2 = /* @__PURE__ */ new Set(), f2 = () => {
            let a11 = ab.getStore();
            if (a11 && (a11.pathWasRevalidated = true), d2 = c2.getAll().filter((a12) => e2.has(a12.name)), b2) {
              let a12 = [];
              for (let b3 of d2) {
                let c3 = new L.ResponseCookies(new Headers());
                c3.set(b3), a12.push(c3.toString());
              }
              b2(a12);
            }
          }, g2 = new Proxy(c2, {
            get(a11, b3, c3) {
              switch (b3) {
                case ae:
                  return d2;
                case "delete":
                  return function(...b4) {
                    e2.add("string" == typeof b4[0] ? b4[0] : b4[0].name);
                    try {
                      return a11.delete(...b4), g2;
                    } finally {
                      f2();
                    }
                  };
                case "set":
                  return function(...b4) {
                    e2.add("string" == typeof b4[0] ? b4[0] : b4[0].name);
                    try {
                      return a11.set(...b4), g2;
                    } finally {
                      f2();
                    }
                  };
                default:
                  return O.get(a11, b3, c3);
              }
            }
          });
          return g2;
        }
      }
      function ag(a10, b2) {
        if ("action" !== a10.phase) throw new ac();
      }
      var ah = function(a10) {
        return a10.handleRequest = "BaseServer.handleRequest", a10.run = "BaseServer.run", a10.pipe = "BaseServer.pipe", a10.getStaticHTML = "BaseServer.getStaticHTML", a10.render = "BaseServer.render", a10.renderToResponseWithComponents = "BaseServer.renderToResponseWithComponents", a10.renderToResponse = "BaseServer.renderToResponse", a10.renderToHTML = "BaseServer.renderToHTML", a10.renderError = "BaseServer.renderError", a10.renderErrorToResponse = "BaseServer.renderErrorToResponse", a10.renderErrorToHTML = "BaseServer.renderErrorToHTML", a10.render404 = "BaseServer.render404", a10;
      }(ah || {}), ai = function(a10) {
        return a10.loadDefaultErrorComponents = "LoadComponents.loadDefaultErrorComponents", a10.loadComponents = "LoadComponents.loadComponents", a10;
      }(ai || {}), aj = function(a10) {
        return a10.getRequestHandler = "NextServer.getRequestHandler", a10.getServer = "NextServer.getServer", a10.getServerRequestHandler = "NextServer.getServerRequestHandler", a10.createServer = "createServer.createServer", a10;
      }(aj || {}), ak = function(a10) {
        return a10.compression = "NextNodeServer.compression", a10.getBuildId = "NextNodeServer.getBuildId", a10.createComponentTree = "NextNodeServer.createComponentTree", a10.clientComponentLoading = "NextNodeServer.clientComponentLoading", a10.getLayoutOrPageModule = "NextNodeServer.getLayoutOrPageModule", a10.generateStaticRoutes = "NextNodeServer.generateStaticRoutes", a10.generateFsStaticRoutes = "NextNodeServer.generateFsStaticRoutes", a10.generatePublicRoutes = "NextNodeServer.generatePublicRoutes", a10.generateImageRoutes = "NextNodeServer.generateImageRoutes.route", a10.sendRenderResult = "NextNodeServer.sendRenderResult", a10.proxyRequest = "NextNodeServer.proxyRequest", a10.runApi = "NextNodeServer.runApi", a10.render = "NextNodeServer.render", a10.renderHTML = "NextNodeServer.renderHTML", a10.imageOptimizer = "NextNodeServer.imageOptimizer", a10.getPagePath = "NextNodeServer.getPagePath", a10.getRoutesManifest = "NextNodeServer.getRoutesManifest", a10.findPageComponents = "NextNodeServer.findPageComponents", a10.getFontManifest = "NextNodeServer.getFontManifest", a10.getServerComponentManifest = "NextNodeServer.getServerComponentManifest", a10.getRequestHandler = "NextNodeServer.getRequestHandler", a10.renderToHTML = "NextNodeServer.renderToHTML", a10.renderError = "NextNodeServer.renderError", a10.renderErrorToHTML = "NextNodeServer.renderErrorToHTML", a10.render404 = "NextNodeServer.render404", a10.startResponse = "NextNodeServer.startResponse", a10.route = "route", a10.onProxyReq = "onProxyReq", a10.apiResolver = "apiResolver", a10.internalFetch = "internalFetch", a10;
      }(ak || {}), al = function(a10) {
        return a10.startServer = "startServer.startServer", a10;
      }(al || {}), am = function(a10) {
        return a10.getServerSideProps = "Render.getServerSideProps", a10.getStaticProps = "Render.getStaticProps", a10.renderToString = "Render.renderToString", a10.renderDocument = "Render.renderDocument", a10.createBodyResult = "Render.createBodyResult", a10;
      }(am || {}), an = function(a10) {
        return a10.renderToString = "AppRender.renderToString", a10.renderToReadableStream = "AppRender.renderToReadableStream", a10.getBodyResult = "AppRender.getBodyResult", a10.fetch = "AppRender.fetch", a10;
      }(an || {}), ao = function(a10) {
        return a10.executeRoute = "Router.executeRoute", a10;
      }(ao || {}), ap = function(a10) {
        return a10.runHandler = "Node.runHandler", a10;
      }(ap || {}), aq = function(a10) {
        return a10.runHandler = "AppRouteRouteHandlers.runHandler", a10;
      }(aq || {}), ar = function(a10) {
        return a10.generateMetadata = "ResolveMetadata.generateMetadata", a10.generateViewport = "ResolveMetadata.generateViewport", a10;
      }(ar || {}), as = function(a10) {
        return a10.execute = "Middleware.execute", a10;
      }(as || {});
      let at = /* @__PURE__ */ new Set([
        "Middleware.execute",
        "BaseServer.handleRequest",
        "Render.getServerSideProps",
        "Render.getStaticProps",
        "AppRender.fetch",
        "AppRender.getBodyResult",
        "Render.renderDocument",
        "Node.runHandler",
        "AppRouteRouteHandlers.runHandler",
        "ResolveMetadata.generateMetadata",
        "ResolveMetadata.generateViewport",
        "NextNodeServer.createComponentTree",
        "NextNodeServer.findPageComponents",
        "NextNodeServer.getLayoutOrPageModule",
        "NextNodeServer.startResponse",
        "NextNodeServer.clientComponentLoading"
      ]), au = /* @__PURE__ */ new Set([
        "NextNodeServer.findPageComponents",
        "NextNodeServer.createComponentTree",
        "NextNodeServer.clientComponentLoading"
      ]);
      function av(a10) {
        return null !== a10 && "object" == typeof a10 && "then" in a10 && "function" == typeof a10.then;
      }
      let aw = process.env.NEXT_OTEL_PERFORMANCE_PREFIX, { context: ax, propagation: ay, trace: az, SpanStatusCode: aA, SpanKind: aB, ROOT_CONTEXT: aC } = d = c(817);
      class aD extends Error {
        constructor(a10, b2) {
          super(), this.bubble = a10, this.result = b2;
        }
      }
      let aE = (a10, b2) => {
        (function(a11) {
          return "object" == typeof a11 && null !== a11 && a11 instanceof aD;
        })(b2) && b2.bubble ? a10.setAttribute("next.bubble", true) : (b2 && (a10.recordException(b2), a10.setAttribute("error.type", b2.name)), a10.setStatus({
          code: aA.ERROR,
          message: null == b2 ? void 0 : b2.message
        })), a10.end();
      }, aF = /* @__PURE__ */ new Map(), aG = d.createContextKey("next.rootSpanId"), aH = 0, aI = {
        set(a10, b2, c2) {
          a10.push({
            key: b2,
            value: c2
          });
        }
      };
      class aJ {
        getTracerInstance() {
          return az.getTracer("next.js", "0.0.1");
        }
        getContext() {
          return ax;
        }
        getTracePropagationData() {
          let a10 = ax.active(), b2 = [];
          return ay.inject(a10, b2, aI), b2;
        }
        getActiveScopeSpan() {
          return az.getSpan(null == ax ? void 0 : ax.active());
        }
        withPropagatedContext(a10, b2, c2) {
          let d2 = ax.active();
          if (az.getSpanContext(d2)) return b2();
          let e2 = ay.extract(d2, a10, c2);
          return ax.with(e2, b2);
        }
        trace(...a10) {
          var b2;
          let [c2, d2, e2] = a10, { fn: f2, options: g2 } = "function" == typeof d2 ? {
            fn: d2,
            options: {}
          } : {
            fn: e2,
            options: {
              ...d2
            }
          }, h2 = g2.spanName ?? c2;
          if (!at.has(c2) && "1" !== process.env.NEXT_OTEL_VERBOSE || g2.hideSpan) return f2();
          let i2 = this.getSpanContext((null == g2 ? void 0 : g2.parentSpan) ?? this.getActiveScopeSpan()), j2 = false;
          i2 ? (null == (b2 = az.getSpanContext(i2)) ? void 0 : b2.isRemote) && (j2 = true) : (i2 = (null == ax ? void 0 : ax.active()) ?? aC, j2 = true);
          let k2 = aH++;
          return g2.attributes = {
            "next.span_name": h2,
            "next.span_type": c2,
            ...g2.attributes
          }, ax.with(i2.setValue(aG, k2), () => this.getTracerInstance().startActiveSpan(h2, g2, (a11) => {
            let b3;
            aw && c2 && au.has(c2) && (b3 = "performance" in globalThis && "measure" in performance ? globalThis.performance.now() : void 0);
            let d3 = false, e3 = () => {
              !d3 && (d3 = true, aF.delete(k2), b3 && performance.measure(`${aw}:next-${(c2.split(".").pop() || "").replace(/[A-Z]/g, (a12) => "-" + a12.toLowerCase())}`, {
                start: b3,
                end: performance.now()
              }));
            };
            if (j2 && aF.set(k2, new Map(Object.entries(g2.attributes ?? {}))), f2.length > 1) try {
              return f2(a11, (b4) => aE(a11, b4));
            } catch (b4) {
              throw aE(a11, b4), b4;
            } finally {
              e3();
            }
            try {
              let b4 = f2(a11);
              if (av(b4)) return b4.then((b5) => (a11.end(), b5)).catch((b5) => {
                throw aE(a11, b5), b5;
              }).finally(e3);
              return a11.end(), e3(), b4;
            } catch (b4) {
              throw aE(a11, b4), e3(), b4;
            }
          }));
        }
        wrap(...a10) {
          let b2 = this, [c2, d2, e2] = 3 === a10.length ? a10 : [
            a10[0],
            {},
            a10[1]
          ];
          return at.has(c2) || "1" === process.env.NEXT_OTEL_VERBOSE ? function() {
            let a11 = d2;
            "function" == typeof a11 && "function" == typeof e2 && (a11 = a11.apply(this, arguments));
            let f2 = arguments.length - 1, g2 = arguments[f2];
            if ("function" != typeof g2) return b2.trace(c2, a11, () => e2.apply(this, arguments));
            {
              let d3 = b2.getContext().bind(ax.active(), g2);
              return b2.trace(c2, a11, (a12, b3) => (arguments[f2] = function(a13) {
                return null == b3 || b3(a13), d3.apply(this, arguments);
              }, e2.apply(this, arguments)));
            }
          } : e2;
        }
        startSpan(...a10) {
          let [b2, c2] = a10, d2 = this.getSpanContext((null == c2 ? void 0 : c2.parentSpan) ?? this.getActiveScopeSpan());
          return this.getTracerInstance().startSpan(b2, c2, d2);
        }
        getSpanContext(a10) {
          return a10 ? az.setSpan(ax.active(), a10) : void 0;
        }
        getRootSpanAttributes() {
          let a10 = ax.active().getValue(aG);
          return aF.get(a10);
        }
        setRootSpanAttribute(a10, b2) {
          let c2 = ax.active().getValue(aG), d2 = aF.get(c2);
          d2 && d2.set(a10, b2);
        }
      }
      let aK = (() => {
        let a10 = new aJ();
        return () => a10;
      })(), aL = "__prerender_bypass";
      Symbol("__next_preview_data"), Symbol(aL);
      class aM {
        constructor(a10, b2, c2, d2) {
          var e2;
          let f2 = a10 && function(a11, b3) {
            let c3 = Y.from(a11.headers);
            return {
              isOnDemandRevalidate: c3.get("x-prerender-revalidate") === b3.previewModeId,
              revalidateOnlyGenerated: c3.has("x-prerender-revalidate-if-generated")
            };
          }(b2, a10).isOnDemandRevalidate, g2 = null == (e2 = c2.get(aL)) ? void 0 : e2.value;
          this._isEnabled = !!(!f2 && g2 && a10 && g2 === a10.previewModeId), this._previewModeId = null == a10 ? void 0 : a10.previewModeId, this._mutableCookies = d2;
        }
        get isEnabled() {
          return this._isEnabled;
        }
        enable() {
          if (!this._previewModeId) throw Object.defineProperty(Error("Invariant: previewProps missing previewModeId this should never happen"), "__NEXT_ERROR_CODE", {
            value: "E93",
            enumerable: false,
            configurable: true
          });
          this._mutableCookies.set({
            name: aL,
            value: this._previewModeId,
            httpOnly: true,
            sameSite: "none",
            secure: true,
            path: "/"
          }), this._isEnabled = true;
        }
        disable() {
          this._mutableCookies.set({
            name: aL,
            value: "",
            httpOnly: true,
            sameSite: "none",
            secure: true,
            path: "/",
            expires: /* @__PURE__ */ new Date(0)
          }), this._isEnabled = false;
        }
      }
      function aN(a10, b2) {
        if ("x-middleware-set-cookie" in a10.headers && "string" == typeof a10.headers["x-middleware-set-cookie"]) {
          let c2 = a10.headers["x-middleware-set-cookie"], d2 = new Headers();
          for (let a11 of s(c2)) d2.append("set-cookie", a11);
          for (let a11 of new L.ResponseCookies(d2).getAll()) b2.set(a11);
        }
      }
      let aO = aa();
      var aP = c(213), aQ = c.n(aP);
      class aR extends Error {
        constructor(a10, b2) {
          super("Invariant: " + (a10.endsWith(".") ? a10 : a10 + ".") + " This is a bug in Next.js.", b2), this.name = "InvariantError";
        }
      }
      class aS {
        constructor(a10, b2, c2) {
          this.prev = null, this.next = null, this.key = a10, this.data = b2, this.size = c2;
        }
      }
      class aT {
        constructor() {
          this.prev = null, this.next = null;
        }
      }
      class aU {
        constructor(a10, b2, c2) {
          this.cache = /* @__PURE__ */ new Map(), this.totalSize = 0, this.maxSize = a10, this.calculateSize = b2, this.onEvict = c2, this.head = new aT(), this.tail = new aT(), this.head.next = this.tail, this.tail.prev = this.head;
        }
        addToHead(a10) {
          a10.prev = this.head, a10.next = this.head.next, this.head.next.prev = a10, this.head.next = a10;
        }
        removeNode(a10) {
          a10.prev.next = a10.next, a10.next.prev = a10.prev;
        }
        moveToHead(a10) {
          this.removeNode(a10), this.addToHead(a10);
        }
        removeTail() {
          let a10 = this.tail.prev;
          return this.removeNode(a10), a10;
        }
        set(a10, b2) {
          let c2 = (null == this.calculateSize ? void 0 : this.calculateSize.call(this, b2)) ?? 1;
          if (c2 <= 0) throw Object.defineProperty(Error(`LRUCache: calculateSize returned ${c2}, but size must be > 0. Items with size 0 would never be evicted, causing unbounded cache growth.`), "__NEXT_ERROR_CODE", {
            value: "E789",
            enumerable: false,
            configurable: true
          });
          if (c2 > this.maxSize) return console.warn("Single item size exceeds maxSize"), false;
          let d2 = this.cache.get(a10);
          if (d2) d2.data = b2, this.totalSize = this.totalSize - d2.size + c2, d2.size = c2, this.moveToHead(d2);
          else {
            let d3 = new aS(a10, b2, c2);
            this.cache.set(a10, d3), this.addToHead(d3), this.totalSize += c2;
          }
          for (; this.totalSize > this.maxSize && this.cache.size > 0; ) {
            let a11 = this.removeTail();
            this.cache.delete(a11.key), this.totalSize -= a11.size, null == this.onEvict || this.onEvict.call(this, a11.key, a11.data);
          }
          return true;
        }
        has(a10) {
          return this.cache.has(a10);
        }
        get(a10) {
          let b2 = this.cache.get(a10);
          if (b2) return this.moveToHead(b2), b2.data;
        }
        *[Symbol.iterator]() {
          let a10 = this.head.next;
          for (; a10 && a10 !== this.tail; ) {
            let b2 = a10;
            yield [
              b2.key,
              b2.data
            ], a10 = a10.next;
          }
        }
        remove(a10) {
          let b2 = this.cache.get(a10);
          b2 && (this.removeNode(b2), this.cache.delete(a10), this.totalSize -= b2.size);
        }
        get size() {
          return this.cache.size;
        }
        get currentSize() {
          return this.totalSize;
        }
      }
      c(356).Buffer, new aU(52428800, (a10) => a10.size), process.env.NEXT_PRIVATE_DEBUG_CACHE && console.debug.bind(console, "DefaultCacheHandler:"), process.env.NEXT_PRIVATE_DEBUG_CACHE && ((a10, ...b2) => {
        console.log(`use-cache: ${a10}`, ...b2);
      }), Symbol.for("@next/cache-handlers");
      let aV = Symbol.for("@next/cache-handlers-map"), aW = Symbol.for("@next/cache-handlers-set"), aX = globalThis;
      function aY() {
        if (aX[aV]) return aX[aV].entries();
      }
      async function aZ(a10, b2) {
        if (!a10) return b2();
        let c2 = a$(a10);
        try {
          return await b2();
        } finally {
          let b3 = function(a11, b4) {
            let c3 = new Set(a11.pendingRevalidatedTags), d2 = new Set(a11.pendingRevalidateWrites);
            return {
              pendingRevalidatedTags: b4.pendingRevalidatedTags.filter((a12) => !c3.has(a12)),
              pendingRevalidates: Object.fromEntries(Object.entries(b4.pendingRevalidates).filter(([b5]) => !(b5 in a11.pendingRevalidates))),
              pendingRevalidateWrites: b4.pendingRevalidateWrites.filter((a12) => !d2.has(a12))
            };
          }(c2, a$(a10));
          await a0(a10, b3);
        }
      }
      function a$(a10) {
        return {
          pendingRevalidatedTags: a10.pendingRevalidatedTags ? [
            ...a10.pendingRevalidatedTags
          ] : [],
          pendingRevalidates: {
            ...a10.pendingRevalidates
          },
          pendingRevalidateWrites: a10.pendingRevalidateWrites ? [
            ...a10.pendingRevalidateWrites
          ] : []
        };
      }
      async function a_(a10, b2) {
        if (0 === a10.length) return;
        let c2 = [];
        b2 && c2.push(b2.revalidateTag(a10));
        let d2 = function() {
          if (aX[aW]) return aX[aW].values();
        }();
        if (d2) for (let b3 of d2) c2.push(b3.expireTags(...a10));
        await Promise.all(c2);
      }
      async function a0(a10, b2) {
        let c2 = (null == b2 ? void 0 : b2.pendingRevalidatedTags) ?? a10.pendingRevalidatedTags ?? [], d2 = (null == b2 ? void 0 : b2.pendingRevalidates) ?? a10.pendingRevalidates ?? {}, e2 = (null == b2 ? void 0 : b2.pendingRevalidateWrites) ?? a10.pendingRevalidateWrites ?? [];
        return Promise.all([
          a_(c2, a10.incrementalCache),
          ...Object.values(d2),
          ...e2
        ]);
      }
      let a1 = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: false,
        configurable: true
      });
      class a2 {
        disable() {
          throw a1;
        }
        getStore() {
        }
        run() {
          throw a1;
        }
        exit() {
          throw a1;
        }
        enterWith() {
          throw a1;
        }
        static bind(a10) {
          return a10;
        }
      }
      let a3 = "undefined" != typeof globalThis && globalThis.AsyncLocalStorage, a4 = a3 ? new a3() : new a2();
      class a5 {
        constructor({ waitUntil: a10, onClose: b2, onTaskError: c2 }) {
          this.workUnitStores = /* @__PURE__ */ new Set(), this.waitUntil = a10, this.onClose = b2, this.onTaskError = c2, this.callbackQueue = new (aQ())(), this.callbackQueue.pause();
        }
        after(a10) {
          if (av(a10)) this.waitUntil || a6(), this.waitUntil(a10.catch((a11) => this.reportTaskError("promise", a11)));
          else if ("function" == typeof a10) this.addCallback(a10);
          else throw Object.defineProperty(Error("`after()`: Argument must be a promise or a function"), "__NEXT_ERROR_CODE", {
            value: "E50",
            enumerable: false,
            configurable: true
          });
        }
        addCallback(a10) {
          var b2;
          this.waitUntil || a6();
          let c2 = aO.getStore();
          c2 && this.workUnitStores.add(c2);
          let d2 = a4.getStore(), e2 = d2 ? d2.rootTaskSpawnPhase : null == c2 ? void 0 : c2.phase;
          this.runCallbacksOnClosePromise || (this.runCallbacksOnClosePromise = this.runCallbacksOnClose(), this.waitUntil(this.runCallbacksOnClosePromise));
          let f2 = (b2 = async () => {
            try {
              await a4.run({
                rootTaskSpawnPhase: e2
              }, () => a10());
            } catch (a11) {
              this.reportTaskError("function", a11);
            }
          }, a3 ? a3.bind(b2) : a2.bind(b2));
          this.callbackQueue.add(f2);
        }
        async runCallbacksOnClose() {
          return await new Promise((a10) => this.onClose(a10)), this.runCallbacks();
        }
        async runCallbacks() {
          if (0 === this.callbackQueue.size) return;
          for (let a11 of this.workUnitStores) a11.phase = "after";
          let a10 = ab.getStore();
          if (!a10) throw Object.defineProperty(new aR("Missing workStore in AfterContext.runCallbacks"), "__NEXT_ERROR_CODE", {
            value: "E547",
            enumerable: false,
            configurable: true
          });
          return aZ(a10, () => (this.callbackQueue.start(), this.callbackQueue.onIdle()));
        }
        reportTaskError(a10, b2) {
          if (console.error("promise" === a10 ? "A promise passed to `after()` rejected:" : "An error occurred in a function passed to `after()`:", b2), this.onTaskError) try {
            null == this.onTaskError || this.onTaskError.call(this, b2);
          } catch (a11) {
            console.error(Object.defineProperty(new aR("`onTaskError` threw while handling an error thrown from an `after` task", {
              cause: a11
            }), "__NEXT_ERROR_CODE", {
              value: "E569",
              enumerable: false,
              configurable: true
            }));
          }
        }
      }
      function a6() {
        throw Object.defineProperty(Error("`after()` will not work correctly, because `waitUntil` is not available in the current environment."), "__NEXT_ERROR_CODE", {
          value: "E91",
          enumerable: false,
          configurable: true
        });
      }
      function a7(a10) {
        let b2, c2 = {
          then: (d2, e2) => (b2 || (b2 = a10()), b2.then((a11) => {
            c2.value = a11;
          }).catch(() => {
          }), b2.then(d2, e2))
        };
        return c2;
      }
      class a8 {
        onClose(a10) {
          if (this.isClosed) throw Object.defineProperty(Error("Cannot subscribe to a closed CloseController"), "__NEXT_ERROR_CODE", {
            value: "E365",
            enumerable: false,
            configurable: true
          });
          this.target.addEventListener("close", a10), this.listeners++;
        }
        dispatchClose() {
          if (this.isClosed) throw Object.defineProperty(Error("Cannot close a CloseController multiple times"), "__NEXT_ERROR_CODE", {
            value: "E229",
            enumerable: false,
            configurable: true
          });
          this.listeners > 0 && this.target.dispatchEvent(new Event("close")), this.isClosed = true;
        }
        constructor() {
          this.target = new EventTarget(), this.listeners = 0, this.isClosed = false;
        }
      }
      function a9() {
        return {
          previewModeId: process.env.__NEXT_PREVIEW_MODE_ID || "",
          previewModeSigningKey: process.env.__NEXT_PREVIEW_MODE_SIGNING_KEY || "",
          previewModeEncryptionKey: process.env.__NEXT_PREVIEW_MODE_ENCRYPTION_KEY || ""
        };
      }
      let ba = Symbol.for("@next/request-context");
      async function bb(a10, b2, c2) {
        let d2 = [], e2 = c2 && c2.size > 0;
        for (let b3 of ((a11) => {
          let b4 = [
            "/layout"
          ];
          if (a11.startsWith("/")) {
            let c3 = a11.split("/");
            for (let a12 = 1; a12 < c3.length + 1; a12++) {
              let d3 = c3.slice(0, a12).join("/");
              d3 && (d3.endsWith("/page") || d3.endsWith("/route") || (d3 = `${d3}${!d3.endsWith("/") ? "/" : ""}layout`), b4.push(d3));
            }
          }
          return b4;
        })(a10)) b3 = `${q}${b3}`, d2.push(b3);
        if (b2.pathname && !e2) {
          let a11 = `${q}${b2.pathname}`;
          d2.push(a11);
        }
        return {
          tags: d2,
          expirationsByCacheKind: function(a11) {
            let b3 = /* @__PURE__ */ new Map(), c3 = aY();
            if (c3) for (let [d3, e3] of c3) "getExpiration" in e3 && b3.set(d3, a7(async () => e3.getExpiration(...a11)));
            return b3;
          }(d2)
        };
      }
      class bc extends N {
        constructor(a10) {
          super(a10.input, a10.init), this.sourcePage = a10.page;
        }
        get request() {
          throw Object.defineProperty(new n({
            page: this.sourcePage
          }), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
          });
        }
        respondWith() {
          throw Object.defineProperty(new n({
            page: this.sourcePage
          }), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
          });
        }
        waitUntil() {
          throw Object.defineProperty(new n({
            page: this.sourcePage
          }), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
          });
        }
      }
      let bd = {
        keys: (a10) => Array.from(a10.keys()),
        get: (a10, b2) => a10.get(b2) ?? void 0
      }, be = (a10, b2) => aK().withPropagatedContext(a10.headers, b2, bd), bf = false;
      async function bg(a10) {
        var b2;
        let d2, e2;
        if (!bf && (bf = true, "true" === process.env.NEXT_PRIVATE_TEST_PROXY)) {
          let { interceptTestApis: a11, wrapRequestHandler: b3 } = c(720);
          a11(), be = b3(be);
        }
        await l();
        let f2 = void 0 !== globalThis.__BUILD_MANIFEST;
        a10.request.url = a10.request.url.replace(/\.rsc($|\?)/, "$1");
        let g2 = a10.bypassNextUrl ? new URL(a10.request.url) : new K(a10.request.url, {
          headers: a10.request.headers,
          nextConfig: a10.request.nextConfig
        });
        for (let a11 of [
          ...g2.searchParams.keys()
        ]) {
          let b3 = g2.searchParams.getAll(a11), c2 = function(a12) {
            for (let b4 of [
              "nxtP",
              "nxtI"
            ]) if (a12 !== b4 && a12.startsWith(b4)) return a12.substring(b4.length);
            return null;
          }(a11);
          if (c2) {
            for (let a12 of (g2.searchParams.delete(c2), b3)) g2.searchParams.append(c2, a12);
            g2.searchParams.delete(a11);
          }
        }
        let h2 = process.env.__NEXT_BUILD_ID || "";
        "buildId" in g2 && (h2 = g2.buildId || "", g2.buildId = "");
        let i2 = function(a11) {
          let b3 = new Headers();
          for (let [c2, d3] of Object.entries(a11)) for (let a12 of Array.isArray(d3) ? d3 : [
            d3
          ]) void 0 !== a12 && ("number" == typeof a12 && (a12 = a12.toString()), b3.append(c2, a12));
          return b3;
        }(a10.request.headers), j2 = i2.has("x-nextjs-data"), k2 = "1" === i2.get("rsc");
        j2 && "/index" === g2.pathname && (g2.pathname = "/");
        let m2 = /* @__PURE__ */ new Map();
        if (!f2) for (let a11 of V) {
          let b3 = i2.get(a11);
          null !== b3 && (m2.set(a11, b3), i2.delete(a11));
        }
        let n2 = g2.searchParams.get(W), o2 = new bc({
          page: a10.page,
          input: function(a11) {
            let b3 = "string" == typeof a11, c2 = b3 ? new URL(a11) : a11;
            return c2.searchParams.delete(W), b3 ? c2.toString() : c2;
          }(g2).toString(),
          init: {
            body: a10.request.body,
            headers: i2,
            method: a10.request.method,
            nextConfig: a10.request.nextConfig,
            signal: a10.request.signal
          }
        });
        j2 && Object.defineProperty(o2, "__isData", {
          enumerable: false,
          value: true
        }), !globalThis.__incrementalCacheShared && a10.IncrementalCache && (globalThis.__incrementalCache = new a10.IncrementalCache({
          CurCacheHandler: a10.incrementalCacheHandler,
          minimalMode: true,
          fetchCacheKeyPrefix: "",
          dev: false,
          requestHeaders: a10.request.headers,
          getPrerenderManifest: () => ({
            version: -1,
            routes: {},
            dynamicRoutes: {},
            notFoundRoutes: [],
            preview: a9()
          })
        }));
        let p2 = a10.request.waitUntil ?? (null == (b2 = function() {
          let a11 = globalThis[ba];
          return null == a11 ? void 0 : a11.get();
        }()) ? void 0 : b2.waitUntil), q2 = new z({
          request: o2,
          page: a10.page,
          context: p2 ? {
            waitUntil: p2
          } : void 0
        });
        if ((d2 = await be(o2, () => {
          if ("/middleware" === a10.page || "/src/middleware" === a10.page) {
            let b3 = q2.waitUntil.bind(q2), c2 = new a8();
            return aK().trace(as.execute, {
              spanName: `middleware ${o2.method} ${o2.nextUrl.pathname}`,
              attributes: {
                "http.target": o2.nextUrl.pathname,
                "http.method": o2.method
              }
            }, async () => {
              try {
                var d3, f3, g3, i3, j3, k3;
                let l2 = a9(), m3 = await bb("/", o2.nextUrl, null), n3 = (j3 = o2.nextUrl, k3 = (a11) => {
                  e2 = a11;
                }, function(a11, b4, c3, d4, e3, f4, g4, h3, i4, j4, k4, l3) {
                  function m4(a12) {
                    c3 && c3.setHeader("Set-Cookie", a12);
                  }
                  let n4 = {};
                  return {
                    type: "request",
                    phase: a11,
                    implicitTags: f4,
                    url: {
                      pathname: d4.pathname,
                      search: d4.search ?? ""
                    },
                    rootParams: e3,
                    get headers() {
                      return n4.headers || (n4.headers = function(a12) {
                        let b5 = Y.from(a12);
                        for (let a13 of V) b5.delete(a13);
                        return Y.seal(b5);
                      }(b4.headers)), n4.headers;
                    },
                    get cookies() {
                      if (!n4.cookies) {
                        let a12 = new L.RequestCookies(Y.from(b4.headers));
                        aN(b4, a12), n4.cookies = ad.seal(a12);
                      }
                      return n4.cookies;
                    },
                    set cookies(value) {
                      n4.cookies = value;
                    },
                    get mutableCookies() {
                      if (!n4.mutableCookies) {
                        let a12 = function(a13, b5) {
                          let c4 = new L.RequestCookies(Y.from(a13));
                          return af.wrap(c4, b5);
                        }(b4.headers, g4 || (c3 ? m4 : void 0));
                        aN(b4, a12), n4.mutableCookies = a12;
                      }
                      return n4.mutableCookies;
                    },
                    get userspaceMutableCookies() {
                      return n4.userspaceMutableCookies || (n4.userspaceMutableCookies = function(a12) {
                        let b5 = new Proxy(a12.mutableCookies, {
                          get(c4, d5, e4) {
                            switch (d5) {
                              case "delete":
                                return function(...d6) {
                                  return ag(a12, "cookies().delete"), c4.delete(...d6), b5;
                                };
                              case "set":
                                return function(...d6) {
                                  return ag(a12, "cookies().set"), c4.set(...d6), b5;
                                };
                              default:
                                return O.get(c4, d5, e4);
                            }
                          }
                        });
                        return b5;
                      }(this)), n4.userspaceMutableCookies;
                    },
                    get draftMode() {
                      return n4.draftMode || (n4.draftMode = new aM(i4, b4, this.cookies, this.mutableCookies)), n4.draftMode;
                    },
                    renderResumeDataCache: h3 ?? null,
                    isHmrRefresh: j4,
                    serverComponentsHmrCache: k4 || globalThis.__serverComponentsHmrCache,
                    devFallbackParams: null
                  };
                }("action", o2, void 0, j3, {}, m3, k3, void 0, l2, false, void 0, null)), p3 = function({ page: a11, renderOpts: b4, isPrefetchRequest: c3, buildId: d4, previouslyRevalidatedTags: e3 }) {
                  var f4;
                  let g4 = !b4.shouldWaitOnAllReady && !b4.supportsDynamicResponse && !b4.isDraftMode && !b4.isPossibleServerAction, h3 = b4.dev ?? false, i4 = h3 || g4 && (!!process.env.NEXT_DEBUG_BUILD || "1" === process.env.NEXT_SSG_FETCH_METRICS), j4 = {
                    isStaticGeneration: g4,
                    page: a11,
                    route: (f4 = a11.split("/").reduce((a12, b5, c4, d5) => b5 ? "(" === b5[0] && b5.endsWith(")") || "@" === b5[0] || ("page" === b5 || "route" === b5) && c4 === d5.length - 1 ? a12 : a12 + "/" + b5 : a12, "")).startsWith("/") ? f4 : "/" + f4,
                    incrementalCache: b4.incrementalCache || globalThis.__incrementalCache,
                    cacheLifeProfiles: b4.cacheLifeProfiles,
                    isRevalidate: b4.isRevalidate,
                    isBuildTimePrerendering: b4.nextExport,
                    hasReadableErrorStacks: b4.hasReadableErrorStacks,
                    fetchCache: b4.fetchCache,
                    isOnDemandRevalidate: b4.isOnDemandRevalidate,
                    isDraftMode: b4.isDraftMode,
                    isPrefetchRequest: c3,
                    buildId: d4,
                    reactLoadableManifest: (null == b4 ? void 0 : b4.reactLoadableManifest) || {},
                    assetPrefix: (null == b4 ? void 0 : b4.assetPrefix) || "",
                    afterContext: function(a12) {
                      let { waitUntil: b5, onClose: c4, onAfterTaskError: d5 } = a12;
                      return new a5({
                        waitUntil: b5,
                        onClose: c4,
                        onTaskError: d5
                      });
                    }(b4),
                    cacheComponentsEnabled: b4.experimental.cacheComponents,
                    dev: h3,
                    previouslyRevalidatedTags: e3,
                    refreshTagsByCacheKind: function() {
                      let a12 = /* @__PURE__ */ new Map(), b5 = aY();
                      if (b5) for (let [c4, d5] of b5) "refreshTags" in d5 && a12.set(c4, a7(async () => d5.refreshTags()));
                      return a12;
                    }(),
                    runInCleanSnapshot: a3 ? a3.snapshot() : function(a12, ...b5) {
                      return a12(...b5);
                    },
                    shouldTrackFetchMetrics: i4
                  };
                  return b4.store = j4, j4;
                }({
                  page: "/",
                  renderOpts: {
                    cacheLifeProfiles: null == (f3 = a10.request.nextConfig) || null == (d3 = f3.experimental) ? void 0 : d3.cacheLife,
                    experimental: {
                      isRoutePPREnabled: false,
                      cacheComponents: false,
                      authInterrupts: !!(null == (i3 = a10.request.nextConfig) || null == (g3 = i3.experimental) ? void 0 : g3.authInterrupts)
                    },
                    supportsDynamicResponse: true,
                    waitUntil: b3,
                    onClose: c2.onClose.bind(c2),
                    onAfterTaskError: void 0
                  },
                  isPrefetchRequest: "1" === o2.headers.get(U),
                  buildId: h2 ?? "",
                  previouslyRevalidatedTags: []
                });
                return await ab.run(p3, () => aO.run(n3, a10.handler, o2, q2));
              } finally {
                setTimeout(() => {
                  c2.dispatchClose();
                }, 0);
              }
            });
          }
          return a10.handler(o2, q2);
        })) && !(d2 instanceof Response)) throw Object.defineProperty(TypeError("Expected an instance of Response to be returned"), "__NEXT_ERROR_CODE", {
          value: "E567",
          enumerable: false,
          configurable: true
        });
        d2 && e2 && d2.headers.set("set-cookie", e2);
        let r2 = null == d2 ? void 0 : d2.headers.get("x-middleware-rewrite");
        if (d2 && r2 && (k2 || !f2)) {
          let b3 = new K(r2, {
            forceLocale: true,
            headers: a10.request.headers,
            nextConfig: a10.request.nextConfig
          });
          f2 || b3.host !== o2.nextUrl.host || (b3.buildId = h2 || b3.buildId, d2.headers.set("x-middleware-rewrite", String(b3)));
          let { url: c2, isRelative: e3 } = T(b3.toString(), g2.toString());
          !f2 && j2 && d2.headers.set("x-nextjs-rewrite", c2), k2 && e3 && (g2.pathname !== b3.pathname && d2.headers.set("x-nextjs-rewritten-path", b3.pathname), g2.search !== b3.search && d2.headers.set("x-nextjs-rewritten-query", b3.search.slice(1)));
        }
        if (d2 && r2 && k2 && n2) {
          let a11 = new URL(r2);
          a11.searchParams.has(W) || (a11.searchParams.set(W, n2), d2.headers.set("x-middleware-rewrite", a11.toString()));
        }
        let s2 = null == d2 ? void 0 : d2.headers.get("Location");
        if (d2 && s2 && !f2) {
          let b3 = new K(s2, {
            forceLocale: false,
            headers: a10.request.headers,
            nextConfig: a10.request.nextConfig
          });
          d2 = new Response(d2.body, d2), b3.host === g2.host && (b3.buildId = h2 || b3.buildId, d2.headers.set("Location", b3.toString())), j2 && (d2.headers.delete("Location"), d2.headers.set("x-nextjs-redirect", T(b3.toString(), g2.toString()).url));
        }
        let t2 = d2 || S.next(), u2 = t2.headers.get("x-middleware-override-headers"), v2 = [];
        if (u2) {
          for (let [a11, b3] of m2) t2.headers.set(`x-middleware-request-${a11}`, b3), v2.push(a11);
          v2.length > 0 && t2.headers.set("x-middleware-override-headers", u2 + "," + v2.join(","));
        }
        return {
          response: t2,
          waitUntil: ("internal" === q2[x].kind ? Promise.all(q2[x].promises).then(() => {
          }) : void 0) ?? Promise.resolve(),
          fetchMetrics: o2.fetchMetrics
        };
      }
      c(449), "undefined" == typeof URLPattern || URLPattern;
      var bh = c(814);
      if (/* @__PURE__ */ new WeakMap(), bh.unstable_postpone, false === function(a10) {
        return a10.includes("needs to bail out of prerendering at this point because it used") && a10.includes("Learn more: https://nextjs.org/docs/messages/ppr-caught-error");
      }("Route %%% needs to bail out of prerendering at this point because it used ^^^. React throws this special object to indicate where. It should not be caught by your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error")) throw Object.defineProperty(Error("Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: false,
        configurable: true
      });
      RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at __next_root_layout_boundary__ \\([^\\n]*\\)`), RegExp(`\\n\\s+at __next_metadata_boundary__[\\n\\s]`), RegExp(`\\n\\s+at __next_viewport_boundary__[\\n\\s]`), RegExp(`\\n\\s+at __next_outlet_boundary__[\\n\\s]`), aa();
      let { env: bi, stdout: bj } = (null == (e = globalThis) ? void 0 : e.process) ?? {}, bk = bi && !bi.NO_COLOR && (bi.FORCE_COLOR || (null == bj ? void 0 : bj.isTTY) && !bi.CI && "dumb" !== bi.TERM), bl = (a10, b2, c2, d2) => {
        let e2 = a10.substring(0, d2) + c2, f2 = a10.substring(d2 + b2.length), g2 = f2.indexOf(b2);
        return ~g2 ? e2 + bl(f2, b2, c2, g2) : e2 + f2;
      }, bm = (a10, b2, c2 = a10) => bk ? (d2) => {
        let e2 = "" + d2, f2 = e2.indexOf(b2, a10.length);
        return ~f2 ? a10 + bl(e2, b2, c2, f2) + b2 : a10 + e2 + b2;
      } : String, bn = bm("\x1B[1m", "\x1B[22m", "\x1B[22m\x1B[1m");
      bm("\x1B[2m", "\x1B[22m", "\x1B[22m\x1B[2m"), bm("\x1B[3m", "\x1B[23m"), bm("\x1B[4m", "\x1B[24m"), bm("\x1B[7m", "\x1B[27m"), bm("\x1B[8m", "\x1B[28m"), bm("\x1B[9m", "\x1B[29m"), bm("\x1B[30m", "\x1B[39m");
      let bo = bm("\x1B[31m", "\x1B[39m"), bp = bm("\x1B[32m", "\x1B[39m"), bq = bm("\x1B[33m", "\x1B[39m");
      bm("\x1B[34m", "\x1B[39m");
      let br = bm("\x1B[35m", "\x1B[39m");
      bm("\x1B[38;2;173;127;168m", "\x1B[39m"), bm("\x1B[36m", "\x1B[39m");
      let bs = bm("\x1B[37m", "\x1B[39m");
      function bt(a10) {
        let { pathname: b2 } = a10.nextUrl;
        if ("/cs" === b2 || b2.startsWith("/cs/")) {
          let c2 = a10.nextUrl.clone();
          return c2.pathname = b2.slice(3) || "/", S.redirect(c2, 308);
        }
        return S.next();
      }
      bm("\x1B[90m", "\x1B[39m"), bm("\x1B[40m", "\x1B[49m"), bm("\x1B[41m", "\x1B[49m"), bm("\x1B[42m", "\x1B[49m"), bm("\x1B[43m", "\x1B[49m"), bm("\x1B[44m", "\x1B[49m"), bm("\x1B[45m", "\x1B[49m"), bm("\x1B[46m", "\x1B[49m"), bm("\x1B[47m", "\x1B[49m"), bs(bn("\u25CB")), bo(bn("\u2A2F")), bq(bn("\u26A0")), bs(bn(" ")), bp(bn("\u2713")), br(bn("\xBB")), new aU(1e4, (a10) => a10.length), /* @__PURE__ */ new WeakMap(), [
        "cs",
        "en",
        "it"
      ].filter((a10) => "cs" !== a10);
      let bu = {
        matcher: [
          "/((?!api|_next|nemovitost/|.*\\..*).*)"
        ]
      };
      Object.values({
        NOT_FOUND: 404,
        FORBIDDEN: 403,
        UNAUTHORIZED: 401
      });
      let bv = {
        ...f
      }, bw = bv.middleware || bv.default, bx = "/middleware";
      if ("function" != typeof bw) throw Object.defineProperty(Error(`The Middleware "${bx}" must export a \`middleware\` or a \`default\` function`), "__NEXT_ERROR_CODE", {
        value: "E120",
        enumerable: false,
        configurable: true
      });
      function by(a10) {
        return bg({
          ...a10,
          page: bx,
          handler: async (...a11) => {
            try {
              return await bw(...a11);
            } catch (e2) {
              let b2 = a11[0], c2 = new URL(b2.url), d2 = c2.pathname + c2.search;
              throw await j(e2, {
                path: d2,
                method: b2.method,
                headers: Object.fromEntries(b2.headers.entries())
              }, {
                routerKind: "Pages Router",
                routePath: "/middleware",
                routeType: "middleware",
                revalidateReason: void 0
              }), e2;
            }
          }
        });
      }
    },
    663: (a) => {
      (() => {
        "use strict";
        "undefined" != typeof __nccwpck_require__ && (__nccwpck_require__.ab = "//");
        var b = {};
        (() => {
          b.parse = function(b2, c2) {
            if ("string" != typeof b2) throw TypeError("argument str must be a string");
            for (var e2 = {}, f = b2.split(d), g = (c2 || {}).decode || a2, h = 0; h < f.length; h++) {
              var i = f[h], j = i.indexOf("=");
              if (!(j < 0)) {
                var k = i.substr(0, j).trim(), l = i.substr(++j, i.length).trim();
                '"' == l[0] && (l = l.slice(1, -1)), void 0 == e2[k] && (e2[k] = function(a3, b3) {
                  try {
                    return b3(a3);
                  } catch (b4) {
                    return a3;
                  }
                }(l, g));
              }
            }
            return e2;
          }, b.serialize = function(a3, b2, d2) {
            var f = d2 || {}, g = f.encode || c;
            if ("function" != typeof g) throw TypeError("option encode is invalid");
            if (!e.test(a3)) throw TypeError("argument name is invalid");
            var h = g(b2);
            if (h && !e.test(h)) throw TypeError("argument val is invalid");
            var i = a3 + "=" + h;
            if (null != f.maxAge) {
              var j = f.maxAge - 0;
              if (isNaN(j) || !isFinite(j)) throw TypeError("option maxAge is invalid");
              i += "; Max-Age=" + Math.floor(j);
            }
            if (f.domain) {
              if (!e.test(f.domain)) throw TypeError("option domain is invalid");
              i += "; Domain=" + f.domain;
            }
            if (f.path) {
              if (!e.test(f.path)) throw TypeError("option path is invalid");
              i += "; Path=" + f.path;
            }
            if (f.expires) {
              if ("function" != typeof f.expires.toUTCString) throw TypeError("option expires is invalid");
              i += "; Expires=" + f.expires.toUTCString();
            }
            if (f.httpOnly && (i += "; HttpOnly"), f.secure && (i += "; Secure"), f.sameSite) switch ("string" == typeof f.sameSite ? f.sameSite.toLowerCase() : f.sameSite) {
              case true:
              case "strict":
                i += "; SameSite=Strict";
                break;
              case "lax":
                i += "; SameSite=Lax";
                break;
              case "none":
                i += "; SameSite=None";
                break;
              default:
                throw TypeError("option sameSite is invalid");
            }
            return i;
          };
          var a2 = decodeURIComponent, c = encodeURIComponent, d = /; */, e = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
        })(), a.exports = b;
      })();
    },
    720: (a, b, c) => {
      "use strict";
      Object.defineProperty(b, "__esModule", {
        value: true
      }), !function(a2, b2) {
        for (var c2 in b2) Object.defineProperty(a2, c2, {
          enumerable: true,
          get: b2[c2]
        });
      }(b, {
        interceptTestApis: function() {
          return f;
        },
        wrapRequestHandler: function() {
          return g;
        }
      });
      let d = c(392), e = c(165);
      function f() {
        return (0, e.interceptFetch)(c.g.fetch);
      }
      function g(a2) {
        return (b2, c2) => (0, d.withRequest)(b2, e.reader, () => a2(b2, c2));
      }
    },
    814: (a, b, c) => {
      "use strict";
      a.exports = c(440);
    },
    817: (a, b, c) => {
      (() => {
        "use strict";
        var b2 = {
          491: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.ContextAPI = void 0;
            let d2 = c2(223), e2 = c2(172), f2 = c2(930), g = "context", h = new d2.NoopContextManager();
            class i {
              constructor() {
              }
              static getInstance() {
                return this._instance || (this._instance = new i()), this._instance;
              }
              setGlobalContextManager(a3) {
                return (0, e2.registerGlobal)(g, a3, f2.DiagAPI.instance());
              }
              active() {
                return this._getContextManager().active();
              }
              with(a3, b4, c3, ...d3) {
                return this._getContextManager().with(a3, b4, c3, ...d3);
              }
              bind(a3, b4) {
                return this._getContextManager().bind(a3, b4);
              }
              _getContextManager() {
                return (0, e2.getGlobal)(g) || h;
              }
              disable() {
                this._getContextManager().disable(), (0, e2.unregisterGlobal)(g, f2.DiagAPI.instance());
              }
            }
            b3.ContextAPI = i;
          },
          930: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.DiagAPI = void 0;
            let d2 = c2(56), e2 = c2(912), f2 = c2(957), g = c2(172);
            class h {
              constructor() {
                function a3(a4) {
                  return function(...b5) {
                    let c3 = (0, g.getGlobal)("diag");
                    if (c3) return c3[a4](...b5);
                  };
                }
                let b4 = this;
                b4.setLogger = (a4, c3 = {
                  logLevel: f2.DiagLogLevel.INFO
                }) => {
                  var d3, h2, i;
                  if (a4 === b4) {
                    let a5 = Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
                    return b4.error(null != (d3 = a5.stack) ? d3 : a5.message), false;
                  }
                  "number" == typeof c3 && (c3 = {
                    logLevel: c3
                  });
                  let j = (0, g.getGlobal)("diag"), k = (0, e2.createLogLevelDiagLogger)(null != (h2 = c3.logLevel) ? h2 : f2.DiagLogLevel.INFO, a4);
                  if (j && !c3.suppressOverrideMessage) {
                    let a5 = null != (i = Error().stack) ? i : "<failed to generate stacktrace>";
                    j.warn(`Current logger will be overwritten from ${a5}`), k.warn(`Current logger will overwrite one already registered from ${a5}`);
                  }
                  return (0, g.registerGlobal)("diag", k, b4, true);
                }, b4.disable = () => {
                  (0, g.unregisterGlobal)("diag", b4);
                }, b4.createComponentLogger = (a4) => new d2.DiagComponentLogger(a4), b4.verbose = a3("verbose"), b4.debug = a3("debug"), b4.info = a3("info"), b4.warn = a3("warn"), b4.error = a3("error");
              }
              static instance() {
                return this._instance || (this._instance = new h()), this._instance;
              }
            }
            b3.DiagAPI = h;
          },
          653: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.MetricsAPI = void 0;
            let d2 = c2(660), e2 = c2(172), f2 = c2(930), g = "metrics";
            class h {
              constructor() {
              }
              static getInstance() {
                return this._instance || (this._instance = new h()), this._instance;
              }
              setGlobalMeterProvider(a3) {
                return (0, e2.registerGlobal)(g, a3, f2.DiagAPI.instance());
              }
              getMeterProvider() {
                return (0, e2.getGlobal)(g) || d2.NOOP_METER_PROVIDER;
              }
              getMeter(a3, b4, c3) {
                return this.getMeterProvider().getMeter(a3, b4, c3);
              }
              disable() {
                (0, e2.unregisterGlobal)(g, f2.DiagAPI.instance());
              }
            }
            b3.MetricsAPI = h;
          },
          181: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.PropagationAPI = void 0;
            let d2 = c2(172), e2 = c2(874), f2 = c2(194), g = c2(277), h = c2(369), i = c2(930), j = "propagation", k = new e2.NoopTextMapPropagator();
            class l {
              constructor() {
                this.createBaggage = h.createBaggage, this.getBaggage = g.getBaggage, this.getActiveBaggage = g.getActiveBaggage, this.setBaggage = g.setBaggage, this.deleteBaggage = g.deleteBaggage;
              }
              static getInstance() {
                return this._instance || (this._instance = new l()), this._instance;
              }
              setGlobalPropagator(a3) {
                return (0, d2.registerGlobal)(j, a3, i.DiagAPI.instance());
              }
              inject(a3, b4, c3 = f2.defaultTextMapSetter) {
                return this._getGlobalPropagator().inject(a3, b4, c3);
              }
              extract(a3, b4, c3 = f2.defaultTextMapGetter) {
                return this._getGlobalPropagator().extract(a3, b4, c3);
              }
              fields() {
                return this._getGlobalPropagator().fields();
              }
              disable() {
                (0, d2.unregisterGlobal)(j, i.DiagAPI.instance());
              }
              _getGlobalPropagator() {
                return (0, d2.getGlobal)(j) || k;
              }
            }
            b3.PropagationAPI = l;
          },
          997: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.TraceAPI = void 0;
            let d2 = c2(172), e2 = c2(846), f2 = c2(139), g = c2(607), h = c2(930), i = "trace";
            class j {
              constructor() {
                this._proxyTracerProvider = new e2.ProxyTracerProvider(), this.wrapSpanContext = f2.wrapSpanContext, this.isSpanContextValid = f2.isSpanContextValid, this.deleteSpan = g.deleteSpan, this.getSpan = g.getSpan, this.getActiveSpan = g.getActiveSpan, this.getSpanContext = g.getSpanContext, this.setSpan = g.setSpan, this.setSpanContext = g.setSpanContext;
              }
              static getInstance() {
                return this._instance || (this._instance = new j()), this._instance;
              }
              setGlobalTracerProvider(a3) {
                let b4 = (0, d2.registerGlobal)(i, this._proxyTracerProvider, h.DiagAPI.instance());
                return b4 && this._proxyTracerProvider.setDelegate(a3), b4;
              }
              getTracerProvider() {
                return (0, d2.getGlobal)(i) || this._proxyTracerProvider;
              }
              getTracer(a3, b4) {
                return this.getTracerProvider().getTracer(a3, b4);
              }
              disable() {
                (0, d2.unregisterGlobal)(i, h.DiagAPI.instance()), this._proxyTracerProvider = new e2.ProxyTracerProvider();
              }
            }
            b3.TraceAPI = j;
          },
          277: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.deleteBaggage = b3.setBaggage = b3.getActiveBaggage = b3.getBaggage = void 0;
            let d2 = c2(491), e2 = (0, c2(780).createContextKey)("OpenTelemetry Baggage Key");
            function f2(a3) {
              return a3.getValue(e2) || void 0;
            }
            b3.getBaggage = f2, b3.getActiveBaggage = function() {
              return f2(d2.ContextAPI.getInstance().active());
            }, b3.setBaggage = function(a3, b4) {
              return a3.setValue(e2, b4);
            }, b3.deleteBaggage = function(a3) {
              return a3.deleteValue(e2);
            };
          },
          993: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.BaggageImpl = void 0;
            class c2 {
              constructor(a3) {
                this._entries = a3 ? new Map(a3) : /* @__PURE__ */ new Map();
              }
              getEntry(a3) {
                let b4 = this._entries.get(a3);
                if (b4) return Object.assign({}, b4);
              }
              getAllEntries() {
                return Array.from(this._entries.entries()).map(([a3, b4]) => [
                  a3,
                  b4
                ]);
              }
              setEntry(a3, b4) {
                let d2 = new c2(this._entries);
                return d2._entries.set(a3, b4), d2;
              }
              removeEntry(a3) {
                let b4 = new c2(this._entries);
                return b4._entries.delete(a3), b4;
              }
              removeEntries(...a3) {
                let b4 = new c2(this._entries);
                for (let c3 of a3) b4._entries.delete(c3);
                return b4;
              }
              clear() {
                return new c2();
              }
            }
            b3.BaggageImpl = c2;
          },
          830: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.baggageEntryMetadataSymbol = void 0, b3.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
          },
          369: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.baggageEntryMetadataFromString = b3.createBaggage = void 0;
            let d2 = c2(930), e2 = c2(993), f2 = c2(830), g = d2.DiagAPI.instance();
            b3.createBaggage = function(a3 = {}) {
              return new e2.BaggageImpl(new Map(Object.entries(a3)));
            }, b3.baggageEntryMetadataFromString = function(a3) {
              return "string" != typeof a3 && (g.error(`Cannot create baggage metadata from unknown type: ${typeof a3}`), a3 = ""), {
                __TYPE__: f2.baggageEntryMetadataSymbol,
                toString: () => a3
              };
            };
          },
          67: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.context = void 0, b3.context = c2(491).ContextAPI.getInstance();
          },
          223: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NoopContextManager = void 0;
            let d2 = c2(780);
            class e2 {
              active() {
                return d2.ROOT_CONTEXT;
              }
              with(a3, b4, c3, ...d3) {
                return b4.call(c3, ...d3);
              }
              bind(a3, b4) {
                return b4;
              }
              enable() {
                return this;
              }
              disable() {
                return this;
              }
            }
            b3.NoopContextManager = e2;
          },
          780: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.ROOT_CONTEXT = b3.createContextKey = void 0, b3.createContextKey = function(a3) {
              return Symbol.for(a3);
            };
            class c2 {
              constructor(a3) {
                let b4 = this;
                b4._currentContext = a3 ? new Map(a3) : /* @__PURE__ */ new Map(), b4.getValue = (a4) => b4._currentContext.get(a4), b4.setValue = (a4, d2) => {
                  let e2 = new c2(b4._currentContext);
                  return e2._currentContext.set(a4, d2), e2;
                }, b4.deleteValue = (a4) => {
                  let d2 = new c2(b4._currentContext);
                  return d2._currentContext.delete(a4), d2;
                };
              }
            }
            b3.ROOT_CONTEXT = new c2();
          },
          506: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.diag = void 0, b3.diag = c2(930).DiagAPI.instance();
          },
          56: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.DiagComponentLogger = void 0;
            let d2 = c2(172);
            class e2 {
              constructor(a3) {
                this._namespace = a3.namespace || "DiagComponentLogger";
              }
              debug(...a3) {
                return f2("debug", this._namespace, a3);
              }
              error(...a3) {
                return f2("error", this._namespace, a3);
              }
              info(...a3) {
                return f2("info", this._namespace, a3);
              }
              warn(...a3) {
                return f2("warn", this._namespace, a3);
              }
              verbose(...a3) {
                return f2("verbose", this._namespace, a3);
              }
            }
            function f2(a3, b4, c3) {
              let e3 = (0, d2.getGlobal)("diag");
              if (e3) return c3.unshift(b4), e3[a3](...c3);
            }
            b3.DiagComponentLogger = e2;
          },
          972: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.DiagConsoleLogger = void 0;
            let c2 = [
              {
                n: "error",
                c: "error"
              },
              {
                n: "warn",
                c: "warn"
              },
              {
                n: "info",
                c: "info"
              },
              {
                n: "debug",
                c: "debug"
              },
              {
                n: "verbose",
                c: "trace"
              }
            ];
            class d2 {
              constructor() {
                for (let a3 = 0; a3 < c2.length; a3++) this[c2[a3].n] = /* @__PURE__ */ function(a4) {
                  return function(...b4) {
                    if (console) {
                      let c3 = console[a4];
                      if ("function" != typeof c3 && (c3 = console.log), "function" == typeof c3) return c3.apply(console, b4);
                    }
                  };
                }(c2[a3].c);
              }
            }
            b3.DiagConsoleLogger = d2;
          },
          912: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.createLogLevelDiagLogger = void 0;
            let d2 = c2(957);
            b3.createLogLevelDiagLogger = function(a3, b4) {
              function c3(c4, d3) {
                let e2 = b4[c4];
                return "function" == typeof e2 && a3 >= d3 ? e2.bind(b4) : function() {
                };
              }
              return a3 < d2.DiagLogLevel.NONE ? a3 = d2.DiagLogLevel.NONE : a3 > d2.DiagLogLevel.ALL && (a3 = d2.DiagLogLevel.ALL), b4 = b4 || {}, {
                error: c3("error", d2.DiagLogLevel.ERROR),
                warn: c3("warn", d2.DiagLogLevel.WARN),
                info: c3("info", d2.DiagLogLevel.INFO),
                debug: c3("debug", d2.DiagLogLevel.DEBUG),
                verbose: c3("verbose", d2.DiagLogLevel.VERBOSE)
              };
            };
          },
          957: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.DiagLogLevel = void 0, function(a3) {
              a3[a3.NONE = 0] = "NONE", a3[a3.ERROR = 30] = "ERROR", a3[a3.WARN = 50] = "WARN", a3[a3.INFO = 60] = "INFO", a3[a3.DEBUG = 70] = "DEBUG", a3[a3.VERBOSE = 80] = "VERBOSE", a3[a3.ALL = 9999] = "ALL";
            }(b3.DiagLogLevel || (b3.DiagLogLevel = {}));
          },
          172: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.unregisterGlobal = b3.getGlobal = b3.registerGlobal = void 0;
            let d2 = c2(200), e2 = c2(521), f2 = c2(130), g = e2.VERSION.split(".")[0], h = Symbol.for(`opentelemetry.js.api.${g}`), i = d2._globalThis;
            b3.registerGlobal = function(a3, b4, c3, d3 = false) {
              var f3;
              let g2 = i[h] = null != (f3 = i[h]) ? f3 : {
                version: e2.VERSION
              };
              if (!d3 && g2[a3]) {
                let b5 = Error(`@opentelemetry/api: Attempted duplicate registration of API: ${a3}`);
                return c3.error(b5.stack || b5.message), false;
              }
              if (g2.version !== e2.VERSION) {
                let b5 = Error(`@opentelemetry/api: Registration of version v${g2.version} for ${a3} does not match previously registered API v${e2.VERSION}`);
                return c3.error(b5.stack || b5.message), false;
              }
              return g2[a3] = b4, c3.debug(`@opentelemetry/api: Registered a global for ${a3} v${e2.VERSION}.`), true;
            }, b3.getGlobal = function(a3) {
              var b4, c3;
              let d3 = null == (b4 = i[h]) ? void 0 : b4.version;
              if (d3 && (0, f2.isCompatible)(d3)) return null == (c3 = i[h]) ? void 0 : c3[a3];
            }, b3.unregisterGlobal = function(a3, b4) {
              b4.debug(`@opentelemetry/api: Unregistering a global for ${a3} v${e2.VERSION}.`);
              let c3 = i[h];
              c3 && delete c3[a3];
            };
          },
          130: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.isCompatible = b3._makeCompatibilityCheck = void 0;
            let d2 = c2(521), e2 = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
            function f2(a3) {
              let b4 = /* @__PURE__ */ new Set([
                a3
              ]), c3 = /* @__PURE__ */ new Set(), d3 = a3.match(e2);
              if (!d3) return () => false;
              let f3 = {
                major: +d3[1],
                minor: +d3[2],
                patch: +d3[3],
                prerelease: d3[4]
              };
              if (null != f3.prerelease) return function(b5) {
                return b5 === a3;
              };
              function g(a4) {
                return c3.add(a4), false;
              }
              return function(a4) {
                if (b4.has(a4)) return true;
                if (c3.has(a4)) return false;
                let d4 = a4.match(e2);
                if (!d4) return g(a4);
                let h = {
                  major: +d4[1],
                  minor: +d4[2],
                  patch: +d4[3],
                  prerelease: d4[4]
                };
                if (null != h.prerelease || f3.major !== h.major) return g(a4);
                if (0 === f3.major) return f3.minor === h.minor && f3.patch <= h.patch ? (b4.add(a4), true) : g(a4);
                return f3.minor <= h.minor ? (b4.add(a4), true) : g(a4);
              };
            }
            b3._makeCompatibilityCheck = f2, b3.isCompatible = f2(d2.VERSION);
          },
          886: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.metrics = void 0, b3.metrics = c2(653).MetricsAPI.getInstance();
          },
          901: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.ValueType = void 0, function(a3) {
              a3[a3.INT = 0] = "INT", a3[a3.DOUBLE = 1] = "DOUBLE";
            }(b3.ValueType || (b3.ValueType = {}));
          },
          102: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.createNoopMeter = b3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = b3.NOOP_OBSERVABLE_GAUGE_METRIC = b3.NOOP_OBSERVABLE_COUNTER_METRIC = b3.NOOP_UP_DOWN_COUNTER_METRIC = b3.NOOP_HISTOGRAM_METRIC = b3.NOOP_COUNTER_METRIC = b3.NOOP_METER = b3.NoopObservableUpDownCounterMetric = b3.NoopObservableGaugeMetric = b3.NoopObservableCounterMetric = b3.NoopObservableMetric = b3.NoopHistogramMetric = b3.NoopUpDownCounterMetric = b3.NoopCounterMetric = b3.NoopMetric = b3.NoopMeter = void 0;
            class c2 {
              constructor() {
              }
              createHistogram(a3, c3) {
                return b3.NOOP_HISTOGRAM_METRIC;
              }
              createCounter(a3, c3) {
                return b3.NOOP_COUNTER_METRIC;
              }
              createUpDownCounter(a3, c3) {
                return b3.NOOP_UP_DOWN_COUNTER_METRIC;
              }
              createObservableGauge(a3, c3) {
                return b3.NOOP_OBSERVABLE_GAUGE_METRIC;
              }
              createObservableCounter(a3, c3) {
                return b3.NOOP_OBSERVABLE_COUNTER_METRIC;
              }
              createObservableUpDownCounter(a3, c3) {
                return b3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
              }
              addBatchObservableCallback(a3, b4) {
              }
              removeBatchObservableCallback(a3) {
              }
            }
            b3.NoopMeter = c2;
            class d2 {
            }
            b3.NoopMetric = d2;
            class e2 extends d2 {
              add(a3, b4) {
              }
            }
            b3.NoopCounterMetric = e2;
            class f2 extends d2 {
              add(a3, b4) {
              }
            }
            b3.NoopUpDownCounterMetric = f2;
            class g extends d2 {
              record(a3, b4) {
              }
            }
            b3.NoopHistogramMetric = g;
            class h {
              addCallback(a3) {
              }
              removeCallback(a3) {
              }
            }
            b3.NoopObservableMetric = h;
            class i extends h {
            }
            b3.NoopObservableCounterMetric = i;
            class j extends h {
            }
            b3.NoopObservableGaugeMetric = j;
            class k extends h {
            }
            b3.NoopObservableUpDownCounterMetric = k, b3.NOOP_METER = new c2(), b3.NOOP_COUNTER_METRIC = new e2(), b3.NOOP_HISTOGRAM_METRIC = new g(), b3.NOOP_UP_DOWN_COUNTER_METRIC = new f2(), b3.NOOP_OBSERVABLE_COUNTER_METRIC = new i(), b3.NOOP_OBSERVABLE_GAUGE_METRIC = new j(), b3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new k(), b3.createNoopMeter = function() {
              return b3.NOOP_METER;
            };
          },
          660: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NOOP_METER_PROVIDER = b3.NoopMeterProvider = void 0;
            let d2 = c2(102);
            class e2 {
              getMeter(a3, b4, c3) {
                return d2.NOOP_METER;
              }
            }
            b3.NoopMeterProvider = e2, b3.NOOP_METER_PROVIDER = new e2();
          },
          200: function(a2, b3, c2) {
            var d2 = this && this.__createBinding || (Object.create ? function(a3, b4, c3, d3) {
              void 0 === d3 && (d3 = c3), Object.defineProperty(a3, d3, {
                enumerable: true,
                get: function() {
                  return b4[c3];
                }
              });
            } : function(a3, b4, c3, d3) {
              void 0 === d3 && (d3 = c3), a3[d3] = b4[c3];
            }), e2 = this && this.__exportStar || function(a3, b4) {
              for (var c3 in a3) "default" === c3 || Object.prototype.hasOwnProperty.call(b4, c3) || d2(b4, a3, c3);
            };
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), e2(c2(46), b3);
          },
          651: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3._globalThis = void 0, b3._globalThis = "object" == typeof globalThis ? globalThis : c.g;
          },
          46: function(a2, b3, c2) {
            var d2 = this && this.__createBinding || (Object.create ? function(a3, b4, c3, d3) {
              void 0 === d3 && (d3 = c3), Object.defineProperty(a3, d3, {
                enumerable: true,
                get: function() {
                  return b4[c3];
                }
              });
            } : function(a3, b4, c3, d3) {
              void 0 === d3 && (d3 = c3), a3[d3] = b4[c3];
            }), e2 = this && this.__exportStar || function(a3, b4) {
              for (var c3 in a3) "default" === c3 || Object.prototype.hasOwnProperty.call(b4, c3) || d2(b4, a3, c3);
            };
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), e2(c2(651), b3);
          },
          939: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.propagation = void 0, b3.propagation = c2(181).PropagationAPI.getInstance();
          },
          874: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NoopTextMapPropagator = void 0;
            class c2 {
              inject(a3, b4) {
              }
              extract(a3, b4) {
                return a3;
              }
              fields() {
                return [];
              }
            }
            b3.NoopTextMapPropagator = c2;
          },
          194: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.defaultTextMapSetter = b3.defaultTextMapGetter = void 0, b3.defaultTextMapGetter = {
              get(a3, b4) {
                if (null != a3) return a3[b4];
              },
              keys: (a3) => null == a3 ? [] : Object.keys(a3)
            }, b3.defaultTextMapSetter = {
              set(a3, b4, c2) {
                null != a3 && (a3[b4] = c2);
              }
            };
          },
          845: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.trace = void 0, b3.trace = c2(997).TraceAPI.getInstance();
          },
          403: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NonRecordingSpan = void 0;
            let d2 = c2(476);
            class e2 {
              constructor(a3 = d2.INVALID_SPAN_CONTEXT) {
                this._spanContext = a3;
              }
              spanContext() {
                return this._spanContext;
              }
              setAttribute(a3, b4) {
                return this;
              }
              setAttributes(a3) {
                return this;
              }
              addEvent(a3, b4) {
                return this;
              }
              setStatus(a3) {
                return this;
              }
              updateName(a3) {
                return this;
              }
              end(a3) {
              }
              isRecording() {
                return false;
              }
              recordException(a3, b4) {
              }
            }
            b3.NonRecordingSpan = e2;
          },
          614: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NoopTracer = void 0;
            let d2 = c2(491), e2 = c2(607), f2 = c2(403), g = c2(139), h = d2.ContextAPI.getInstance();
            class i {
              startSpan(a3, b4, c3 = h.active()) {
                var d3;
                if (null == b4 ? void 0 : b4.root) return new f2.NonRecordingSpan();
                let i2 = c3 && (0, e2.getSpanContext)(c3);
                return "object" == typeof (d3 = i2) && "string" == typeof d3.spanId && "string" == typeof d3.traceId && "number" == typeof d3.traceFlags && (0, g.isSpanContextValid)(i2) ? new f2.NonRecordingSpan(i2) : new f2.NonRecordingSpan();
              }
              startActiveSpan(a3, b4, c3, d3) {
                let f3, g2, i2;
                if (arguments.length < 2) return;
                2 == arguments.length ? i2 = b4 : 3 == arguments.length ? (f3 = b4, i2 = c3) : (f3 = b4, g2 = c3, i2 = d3);
                let j = null != g2 ? g2 : h.active(), k = this.startSpan(a3, f3, j), l = (0, e2.setSpan)(j, k);
                return h.with(l, i2, void 0, k);
              }
            }
            b3.NoopTracer = i;
          },
          124: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.NoopTracerProvider = void 0;
            let d2 = c2(614);
            class e2 {
              getTracer(a3, b4, c3) {
                return new d2.NoopTracer();
              }
            }
            b3.NoopTracerProvider = e2;
          },
          125: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.ProxyTracer = void 0;
            let d2 = new (c2(614)).NoopTracer();
            class e2 {
              constructor(a3, b4, c3, d3) {
                this._provider = a3, this.name = b4, this.version = c3, this.options = d3;
              }
              startSpan(a3, b4, c3) {
                return this._getTracer().startSpan(a3, b4, c3);
              }
              startActiveSpan(a3, b4, c3, d3) {
                let e3 = this._getTracer();
                return Reflect.apply(e3.startActiveSpan, e3, arguments);
              }
              _getTracer() {
                if (this._delegate) return this._delegate;
                let a3 = this._provider.getDelegateTracer(this.name, this.version, this.options);
                return a3 ? (this._delegate = a3, this._delegate) : d2;
              }
            }
            b3.ProxyTracer = e2;
          },
          846: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.ProxyTracerProvider = void 0;
            let d2 = c2(125), e2 = new (c2(124)).NoopTracerProvider();
            class f2 {
              getTracer(a3, b4, c3) {
                var e3;
                return null != (e3 = this.getDelegateTracer(a3, b4, c3)) ? e3 : new d2.ProxyTracer(this, a3, b4, c3);
              }
              getDelegate() {
                var a3;
                return null != (a3 = this._delegate) ? a3 : e2;
              }
              setDelegate(a3) {
                this._delegate = a3;
              }
              getDelegateTracer(a3, b4, c3) {
                var d3;
                return null == (d3 = this._delegate) ? void 0 : d3.getTracer(a3, b4, c3);
              }
            }
            b3.ProxyTracerProvider = f2;
          },
          996: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.SamplingDecision = void 0, function(a3) {
              a3[a3.NOT_RECORD = 0] = "NOT_RECORD", a3[a3.RECORD = 1] = "RECORD", a3[a3.RECORD_AND_SAMPLED = 2] = "RECORD_AND_SAMPLED";
            }(b3.SamplingDecision || (b3.SamplingDecision = {}));
          },
          607: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.getSpanContext = b3.setSpanContext = b3.deleteSpan = b3.setSpan = b3.getActiveSpan = b3.getSpan = void 0;
            let d2 = c2(780), e2 = c2(403), f2 = c2(491), g = (0, d2.createContextKey)("OpenTelemetry Context Key SPAN");
            function h(a3) {
              return a3.getValue(g) || void 0;
            }
            function i(a3, b4) {
              return a3.setValue(g, b4);
            }
            b3.getSpan = h, b3.getActiveSpan = function() {
              return h(f2.ContextAPI.getInstance().active());
            }, b3.setSpan = i, b3.deleteSpan = function(a3) {
              return a3.deleteValue(g);
            }, b3.setSpanContext = function(a3, b4) {
              return i(a3, new e2.NonRecordingSpan(b4));
            }, b3.getSpanContext = function(a3) {
              var b4;
              return null == (b4 = h(a3)) ? void 0 : b4.spanContext();
            };
          },
          325: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.TraceStateImpl = void 0;
            let d2 = c2(564);
            class e2 {
              constructor(a3) {
                this._internalState = /* @__PURE__ */ new Map(), a3 && this._parse(a3);
              }
              set(a3, b4) {
                let c3 = this._clone();
                return c3._internalState.has(a3) && c3._internalState.delete(a3), c3._internalState.set(a3, b4), c3;
              }
              unset(a3) {
                let b4 = this._clone();
                return b4._internalState.delete(a3), b4;
              }
              get(a3) {
                return this._internalState.get(a3);
              }
              serialize() {
                return this._keys().reduce((a3, b4) => (a3.push(b4 + "=" + this.get(b4)), a3), []).join(",");
              }
              _parse(a3) {
                !(a3.length > 512) && (this._internalState = a3.split(",").reverse().reduce((a4, b4) => {
                  let c3 = b4.trim(), e3 = c3.indexOf("=");
                  if (-1 !== e3) {
                    let f2 = c3.slice(0, e3), g = c3.slice(e3 + 1, b4.length);
                    (0, d2.validateKey)(f2) && (0, d2.validateValue)(g) && a4.set(f2, g);
                  }
                  return a4;
                }, /* @__PURE__ */ new Map()), this._internalState.size > 32 && (this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, 32))));
              }
              _keys() {
                return Array.from(this._internalState.keys()).reverse();
              }
              _clone() {
                let a3 = new e2();
                return a3._internalState = new Map(this._internalState), a3;
              }
            }
            b3.TraceStateImpl = e2;
          },
          564: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.validateValue = b3.validateKey = void 0;
            let c2 = "[_0-9a-z-*/]", d2 = `[a-z]${c2}{0,255}`, e2 = `[a-z0-9]${c2}{0,240}@[a-z]${c2}{0,13}`, f2 = RegExp(`^(?:${d2}|${e2})$`), g = /^[ -~]{0,255}[!-~]$/, h = /,|=/;
            b3.validateKey = function(a3) {
              return f2.test(a3);
            }, b3.validateValue = function(a3) {
              return g.test(a3) && !h.test(a3);
            };
          },
          98: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.createTraceState = void 0;
            let d2 = c2(325);
            b3.createTraceState = function(a3) {
              return new d2.TraceStateImpl(a3);
            };
          },
          476: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.INVALID_SPAN_CONTEXT = b3.INVALID_TRACEID = b3.INVALID_SPANID = void 0;
            let d2 = c2(475);
            b3.INVALID_SPANID = "0000000000000000", b3.INVALID_TRACEID = "00000000000000000000000000000000", b3.INVALID_SPAN_CONTEXT = {
              traceId: b3.INVALID_TRACEID,
              spanId: b3.INVALID_SPANID,
              traceFlags: d2.TraceFlags.NONE
            };
          },
          357: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.SpanKind = void 0, function(a3) {
              a3[a3.INTERNAL = 0] = "INTERNAL", a3[a3.SERVER = 1] = "SERVER", a3[a3.CLIENT = 2] = "CLIENT", a3[a3.PRODUCER = 3] = "PRODUCER", a3[a3.CONSUMER = 4] = "CONSUMER";
            }(b3.SpanKind || (b3.SpanKind = {}));
          },
          139: (a2, b3, c2) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.wrapSpanContext = b3.isSpanContextValid = b3.isValidSpanId = b3.isValidTraceId = void 0;
            let d2 = c2(476), e2 = c2(403), f2 = /^([0-9a-f]{32})$/i, g = /^[0-9a-f]{16}$/i;
            function h(a3) {
              return f2.test(a3) && a3 !== d2.INVALID_TRACEID;
            }
            function i(a3) {
              return g.test(a3) && a3 !== d2.INVALID_SPANID;
            }
            b3.isValidTraceId = h, b3.isValidSpanId = i, b3.isSpanContextValid = function(a3) {
              return h(a3.traceId) && i(a3.spanId);
            }, b3.wrapSpanContext = function(a3) {
              return new e2.NonRecordingSpan(a3);
            };
          },
          847: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.SpanStatusCode = void 0, function(a3) {
              a3[a3.UNSET = 0] = "UNSET", a3[a3.OK = 1] = "OK", a3[a3.ERROR = 2] = "ERROR";
            }(b3.SpanStatusCode || (b3.SpanStatusCode = {}));
          },
          475: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.TraceFlags = void 0, function(a3) {
              a3[a3.NONE = 0] = "NONE", a3[a3.SAMPLED = 1] = "SAMPLED";
            }(b3.TraceFlags || (b3.TraceFlags = {}));
          },
          521: (a2, b3) => {
            Object.defineProperty(b3, "__esModule", {
              value: true
            }), b3.VERSION = void 0, b3.VERSION = "1.6.0";
          }
        }, d = {};
        function e(a2) {
          var c2 = d[a2];
          if (void 0 !== c2) return c2.exports;
          var f2 = d[a2] = {
            exports: {}
          }, g = true;
          try {
            b2[a2].call(f2.exports, f2, f2.exports, e), g = false;
          } finally {
            g && delete d[a2];
          }
          return f2.exports;
        }
        e.ab = "//";
        var f = {};
        (() => {
          Object.defineProperty(f, "__esModule", {
            value: true
          }), f.trace = f.propagation = f.metrics = f.diag = f.context = f.INVALID_SPAN_CONTEXT = f.INVALID_TRACEID = f.INVALID_SPANID = f.isValidSpanId = f.isValidTraceId = f.isSpanContextValid = f.createTraceState = f.TraceFlags = f.SpanStatusCode = f.SpanKind = f.SamplingDecision = f.ProxyTracerProvider = f.ProxyTracer = f.defaultTextMapSetter = f.defaultTextMapGetter = f.ValueType = f.createNoopMeter = f.DiagLogLevel = f.DiagConsoleLogger = f.ROOT_CONTEXT = f.createContextKey = f.baggageEntryMetadataFromString = void 0;
          var a2 = e(369);
          Object.defineProperty(f, "baggageEntryMetadataFromString", {
            enumerable: true,
            get: function() {
              return a2.baggageEntryMetadataFromString;
            }
          });
          var b3 = e(780);
          Object.defineProperty(f, "createContextKey", {
            enumerable: true,
            get: function() {
              return b3.createContextKey;
            }
          }), Object.defineProperty(f, "ROOT_CONTEXT", {
            enumerable: true,
            get: function() {
              return b3.ROOT_CONTEXT;
            }
          });
          var c2 = e(972);
          Object.defineProperty(f, "DiagConsoleLogger", {
            enumerable: true,
            get: function() {
              return c2.DiagConsoleLogger;
            }
          });
          var d2 = e(957);
          Object.defineProperty(f, "DiagLogLevel", {
            enumerable: true,
            get: function() {
              return d2.DiagLogLevel;
            }
          });
          var g = e(102);
          Object.defineProperty(f, "createNoopMeter", {
            enumerable: true,
            get: function() {
              return g.createNoopMeter;
            }
          });
          var h = e(901);
          Object.defineProperty(f, "ValueType", {
            enumerable: true,
            get: function() {
              return h.ValueType;
            }
          });
          var i = e(194);
          Object.defineProperty(f, "defaultTextMapGetter", {
            enumerable: true,
            get: function() {
              return i.defaultTextMapGetter;
            }
          }), Object.defineProperty(f, "defaultTextMapSetter", {
            enumerable: true,
            get: function() {
              return i.defaultTextMapSetter;
            }
          });
          var j = e(125);
          Object.defineProperty(f, "ProxyTracer", {
            enumerable: true,
            get: function() {
              return j.ProxyTracer;
            }
          });
          var k = e(846);
          Object.defineProperty(f, "ProxyTracerProvider", {
            enumerable: true,
            get: function() {
              return k.ProxyTracerProvider;
            }
          });
          var l = e(996);
          Object.defineProperty(f, "SamplingDecision", {
            enumerable: true,
            get: function() {
              return l.SamplingDecision;
            }
          });
          var m = e(357);
          Object.defineProperty(f, "SpanKind", {
            enumerable: true,
            get: function() {
              return m.SpanKind;
            }
          });
          var n = e(847);
          Object.defineProperty(f, "SpanStatusCode", {
            enumerable: true,
            get: function() {
              return n.SpanStatusCode;
            }
          });
          var o = e(475);
          Object.defineProperty(f, "TraceFlags", {
            enumerable: true,
            get: function() {
              return o.TraceFlags;
            }
          });
          var p = e(98);
          Object.defineProperty(f, "createTraceState", {
            enumerable: true,
            get: function() {
              return p.createTraceState;
            }
          });
          var q = e(139);
          Object.defineProperty(f, "isSpanContextValid", {
            enumerable: true,
            get: function() {
              return q.isSpanContextValid;
            }
          }), Object.defineProperty(f, "isValidTraceId", {
            enumerable: true,
            get: function() {
              return q.isValidTraceId;
            }
          }), Object.defineProperty(f, "isValidSpanId", {
            enumerable: true,
            get: function() {
              return q.isValidSpanId;
            }
          });
          var r = e(476);
          Object.defineProperty(f, "INVALID_SPANID", {
            enumerable: true,
            get: function() {
              return r.INVALID_SPANID;
            }
          }), Object.defineProperty(f, "INVALID_TRACEID", {
            enumerable: true,
            get: function() {
              return r.INVALID_TRACEID;
            }
          }), Object.defineProperty(f, "INVALID_SPAN_CONTEXT", {
            enumerable: true,
            get: function() {
              return r.INVALID_SPAN_CONTEXT;
            }
          });
          let s = e(67);
          Object.defineProperty(f, "context", {
            enumerable: true,
            get: function() {
              return s.context;
            }
          });
          let t = e(506);
          Object.defineProperty(f, "diag", {
            enumerable: true,
            get: function() {
              return t.diag;
            }
          });
          let u = e(886);
          Object.defineProperty(f, "metrics", {
            enumerable: true,
            get: function() {
              return u.metrics;
            }
          });
          let v = e(939);
          Object.defineProperty(f, "propagation", {
            enumerable: true,
            get: function() {
              return v.propagation;
            }
          });
          let w = e(845);
          Object.defineProperty(f, "trace", {
            enumerable: true,
            get: function() {
              return w.trace;
            }
          }), f.default = {
            context: s.context,
            diag: t.diag,
            metrics: u.metrics,
            propagation: v.propagation,
            trace: w.trace
          };
        })(), a.exports = f;
      })();
    }
  },
  (a) => {
    var b = a(a.s = 571);
    (_ENTRIES = "undefined" == typeof _ENTRIES ? {} : _ENTRIES).middleware_middleware = b;
  }
]);
var middlewareEntryKey = Object.keys(_ENTRIES).find((entryKey) => entryKey.startsWith("middleware_middleware"));
var middleware_default = await _ENTRIES[middlewareEntryKey].default;

// .netlify/edge-functions/___netlify-edge-handler-middleware/___netlify-edge-handler-middleware.js
var netlify_edge_handler_middleware_default = (req, context) => handleMiddleware(req, context, middleware_default);
export {
  netlify_edge_handler_middleware_default as default
};
